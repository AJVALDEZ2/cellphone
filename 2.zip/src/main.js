const { app, BrowserWindow, ipcMain } = require("electron")
const path = require("path")
const {
  pool,
  initializeDatabase,
  logActivity,
  getAllProducts,
  getProductById,
  createProduct,
  updateProduct,
  deleteProduct,
  getAllSales,
  getSaleById,
  createSale,
  getAllRepairs,
  getRepairById,
  createRepair,
  updateRepair,
  deleteRepair,
  getAllCommissions,
  getCashierCommissions,
  getCommissionById,
  createCommission,
  updateCommissionPayment,
  getCashiers,
  generateSalesReport,
  generateRepairReport,
  generateCommissionReport,
  generateInventoryReport,
  getAllUsers,
  getUserById,
  createUser,
  updateUser,
  deleteUser,
  getLowStockProducts,
  adjustProductStock,
} = require("./db")
const bcrypt = require("bcryptjs")

let mainWindow
let currentSession = null

// Initialize database
initializeDatabase()

// Create the main application window
function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 1200,
    minHeight: 800,
    title: "Cellphone Repair Shop Management System",
    icon: path.join(__dirname, "../public/img/icon.png"),
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, "preload.js"),
    },
    show: false,
    titleBarStyle: "default",
    backgroundColor: "#f8fafc",
  })

  mainWindow.once("ready-to-show", () => {
    mainWindow.show()
    if (process.argv.includes("--dev")) {
      mainWindow.webContents.openDevTools()
    }
  })

  // Load login UI initially
  mainWindow.loadFile(path.join(__dirname, "../public/index.html"))
}

// Helper: Load dashboard based on role
function loadDashboardByRole(role) {
  const dashboards = {
    admin: "admin.html",
    cashier: "cashier.html",
  }
  const file = dashboards[role?.toLowerCase()] || "admin.html"
  mainWindow.loadFile(path.join(__dirname, `../public/${file}`))
}

// Electron app lifecycle
app.whenReady().then(() => {
  createWindow()

  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow()
  })
})

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit()
})

// IPC handlers
ipcMain.handle("getCurrentSession", () => currentSession)

// Login
ipcMain.handle("login", async (_, { email, password }) => {
  try {
    if (!email || !password) {
      return { success: false, message: "Email and password are required." }
    }
    const [rows] = await pool.query(
      `SELECT users.id, users.name, users.email, users.password, users.role_id, roles.name as role
             FROM users LEFT JOIN roles ON users.role_id = roles.id
             WHERE users.email = ?`,
      [email],
    )
    if (!rows.length) {
      return { success: false, message: "No account found with this email." }
    }
    const user = rows[0]
    if (!["Admin", "Cashier"].includes(user.role)) {
      return { success: false, message: "Access denied. Only Admin and Cashier roles are allowed." }
    }
    const match = await bcrypt.compare(password, user.password)
    if (!match) {
      return { success: false, message: "Incorrect password." }
    }
    currentSession = {
      userId: user.id,
      name: user.name,
      role: user.role,
      email: user.email,
    }
    // Log login activity
    await logActivity({
      userId: user.id,
      userName: user.name,
      role: user.role,
      action: "User Login",
      details: `User ${user.name} logged in successfully`,
    })
    loadDashboardByRole(user.role)
    return {
      success: true,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
      },
      message: `Welcome back, ${user.name}!`,
    }
  } catch (error) {
    console.error("Login error:", error)
    return { success: false, message: "Login failed. Please try again." }
  }
})

// Logout
ipcMain.on("logout", async () => {
  if (currentSession) {
    await logActivity({
      userId: currentSession.userId,
      userName: currentSession.name,
      role: currentSession.role,
      action: "User Logout",
      details: `User ${currentSession.name} logged out`,
    })
  }
  currentSession = null
  mainWindow.loadFile(path.join(__dirname, "../public/index.html"))
})

// --- CELLPHONE REPAIR SHOP API ENDPOINTS ---

// --- PRODUCTS API ---
ipcMain.handle("getProducts", async () => {
  return await getAllProducts()
})

ipcMain.handle("getProductById", async (_, id) => {
  return await getProductById(id)
})

ipcMain.handle("createProduct", async (_, productData) => {
  return await createProduct(productData)
})

ipcMain.handle("updateProduct", async (_, productData) => {
  return await updateProduct(productData)
})

ipcMain.handle("deleteProduct", async (_, id) => {
  return await deleteProduct(id)
})

// Add after existing product endpoints
ipcMain.handle("getLowStockProducts", async () => {
  return await getLowStockProducts()
})

ipcMain.handle("adjustProductStock", async (_, adjustmentData) => {
  return await adjustProductStock(adjustmentData)
})

// --- SALES API ---
ipcMain.handle("getSales", async () => {
  return await getAllSales()
})

ipcMain.handle("getSaleById", async (_, id) => {
  return await getSaleById(id)
})

ipcMain.handle("createSale", async (_, saleData) => {
  return await createSale(saleData)
})

// --- REPAIRS API ---
ipcMain.handle("getRepairs", async () => {
  return await getAllRepairs()
})

ipcMain.handle("getRepairById", async (_, id) => {
  return await getRepairById(id)
})

ipcMain.handle("createRepair", async (_, repairData) => {
  return await createRepair(repairData)
})

ipcMain.handle("updateRepair", async (_, repairData) => {
  return await updateRepair(repairData)
})

ipcMain.handle("deleteRepair", async (_, id) => {
  return await deleteRepair(id)
})

// --- COMMISSIONS API ---
ipcMain.handle("getCommissions", async () => {
  return await getAllCommissions()
})

ipcMain.handle("getCashierCommissions", async () => {
  if (!currentSession || !currentSession.userId) {
    return { success: false, message: "Not logged in" }
  }
  return await getCashierCommissions(currentSession.userId)
})

ipcMain.handle("getCommissionById", async (_, id) => {
  return await getCommissionById(id)
})

ipcMain.handle("createCommission", async (_, commissionData) => {
  return await createCommission(commissionData)
})

ipcMain.handle("updateCommissionPayment", async (_, paymentData) => {
  return await updateCommissionPayment(paymentData)
})

// --- REPORTS API ---
ipcMain.handle("getCashiers", async () => {
  return await getCashiers()
})

ipcMain.handle("generateSalesReport", async (_, filters) => {
  return await generateSalesReport(filters)
})

ipcMain.handle("generateRepairReport", async (_, filters) => {
  return await generateRepairReport(filters)
})

ipcMain.handle("generateCommissionReport", async (_, filters) => {
  return await generateCommissionReport(filters)
})

ipcMain.handle("generateInventoryReport", async (_, filters) => {
  return await generateInventoryReport(filters)
})

// --- USER MANAGEMENT API ---
ipcMain.handle("getUsers", async () => {
  return await getAllUsers()
})

ipcMain.handle("getUserById", async (_, id) => {
  return await getUserById(id)
})

ipcMain.handle("createUser", async (_, userData) => {
  return await createUser(userData)
})

ipcMain.handle("updateUser", async (_, userData) => {
  return await updateUser(userData)
})

ipcMain.handle("deleteUser", async (_, id) => {
  return await deleteUser(id)
})

module.exports = { app, mainWindow }
