const mysql = require("mysql2/promise")
const bcrypt = require("bcryptjs")
require("dotenv").config()

const pool = mysql.createPool({
  host: process.env.DB_HOST || "localhost",
  port: process.env.DB_PORT || 3306,
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD || "",
  database: process.env.DB_NAME || "cellphone",
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
})

async function initializeDatabase() {
  let connection
  try {
    connection = await pool.getConnection()

    // Create roles table
    await connection.query(`
      CREATE TABLE IF NOT EXISTS roles (
        id INT PRIMARY KEY AUTO_INCREMENT,
        name VARCHAR(50) UNIQUE NOT NULL
      );
    `)
    // Create users table
    await connection.query(`
      CREATE TABLE IF NOT EXISTS users (
        id INT PRIMARY KEY AUTO_INCREMENT,
        name VARCHAR(50) NOT NULL,
        password VARCHAR(255) DEFAULT NULL,
        email VARCHAR(100) UNIQUE NOT NULL,
        is_active TINYINT(1) DEFAULT 1,
        role_id INT DEFAULT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE SET NULL
      );
    `)
    // Create products table
    await connection.query(`
      CREATE TABLE IF NOT EXISTS products (
        id INT PRIMARY KEY AUTO_INCREMENT,
        name VARCHAR(100) NOT NULL,
        description TEXT,
        category VARCHAR(50),
        price DECIMAL(10,2) NOT NULL,
        stock INT NOT NULL DEFAULT 0,
        low_stock_threshold INT DEFAULT 5,
        is_active BOOLEAN DEFAULT 1
      );
    `)
    // Create sales table
    await connection.query(`
      CREATE TABLE IF NOT EXISTS sales (
        id INT PRIMARY KEY AUTO_INCREMENT,
        date DATETIME DEFAULT CURRENT_TIMESTAMP,
        cashier_id INT,
        client_name VARCHAR(100),
        total_amount DECIMAL(10,2) NOT NULL,
        payment_method VARCHAR(50),
        FOREIGN KEY (cashier_id) REFERENCES users(id)
      );
    `)
    // Create sale_items table
    await connection.query(`
      CREATE TABLE IF NOT EXISTS sale_items (
        id INT PRIMARY KEY AUTO_INCREMENT,
        sale_id INT,
        product_id INT,
        quantity INT NOT NULL,
        unit_price DECIMAL(10,2) NOT NULL,
        total_price DECIMAL(10,2) NOT NULL,
        FOREIGN KEY (sale_id) REFERENCES sales(id),
        FOREIGN KEY (product_id) REFERENCES products(id)
      );
    `)
    // Create repairs table
    await connection.query(`
      CREATE TABLE IF NOT EXISTS repairs (
        id INT PRIMARY KEY AUTO_INCREMENT,
        date DATETIME DEFAULT CURRENT_TIMESTAMP,
        client_name VARCHAR(100),
        client_phone VARCHAR(20),
        device_model VARCHAR(100),
        issue_description TEXT,
        parts_used TEXT,
        service_fee DECIMAL(10,2) NOT NULL,
        commission_amount DECIMAL(10,2),
        status ENUM('Pending', 'In Progress', 'Completed', 'Released') DEFAULT 'Pending',
        cashier_id INT,
        FOREIGN KEY (cashier_id) REFERENCES users(id)
      );
    `)
    // Create commissions table
    await connection.query(`
      CREATE TABLE IF NOT EXISTS commissions (
        id INT PRIMARY KEY AUTO_INCREMENT,
        repair_id INT,
        cashier_id INT,
        commission_amount DECIMAL(10,2) NOT NULL,
        date DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (repair_id) REFERENCES repairs(id),
        FOREIGN KEY (cashier_id) REFERENCES users(id)
      );
    `)
    // Create activity_log table (optional, for tracking)
    await connection.query(`
      CREATE TABLE IF NOT EXISTS activity_log (
        id INT PRIMARY KEY AUTO_INCREMENT,
        user_id INT NOT NULL,
        user_name VARCHAR(100) NOT NULL,
        role VARCHAR(50) NOT NULL,
        action VARCHAR(255) NOT NULL,
        details TEXT DEFAULT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      );
    `)
    // Create reports table (optional)
    await connection.query(`
      CREATE TABLE IF NOT EXISTS reports (
        id INT PRIMARY KEY AUTO_INCREMENT,
        report_name VARCHAR(100) NOT NULL,
        generated_by INT DEFAULT NULL,
        generated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (generated_by) REFERENCES users(id) ON DELETE SET NULL
      );
    `)

    // Insert base roles if not present
    const [roleRows] = await connection.query("SELECT COUNT(*) AS count FROM roles;")
    if (roleRows[0].count === 0) {
      await connection.query(`
        INSERT INTO roles (name) VALUES
          ('Admin'),
          ('Cashier');
      `)
    }

    // Insert provided users if not present
    const [userRows] = await connection.query("SELECT COUNT(*) AS count FROM users;")
    if (userRows[0].count === 0) {
      await connection.query(`
        INSERT INTO users (id, name, password, email, is_active, role_id, created_at, updated_at) VALUES
          (1, 'admin', '$2a$10$SNdhA22VF9vcbZK7GiCBo.YuM3PGKYLU/m.S3MhGWlYJ/kpmyk29u', 'admin@gmail.com', 1, 1, NOW(), NOW()),
          (2, 'cashier', '$2a$10$IxSsjqO3YCzBbACmYCb3dObEGtBwVn28s0cmaygT3ejx5lu1YOIl2', 'cashier@gmail.com', 1, 2, NOW(), NOW());
      `)
    }

    console.log("✅ Database initialized successfully - Ready for admin and cashier use")
  } catch (error) {
    console.error("❌ Database initialization failed:", error)
    process.exit(1)
  } finally {
    if (connection) connection.release()
  }
}

async function clearAllTables() {
  let connection
  try {
    connection = await pool.getConnection()
    await connection.query("SET FOREIGN_KEY_CHECKS = 0;")
    await connection.query("DELETE FROM activity_log;")
    await connection.query("DELETE FROM commissions;")
    await connection.query("DELETE FROM repairs;")
    await connection.query("DELETE FROM sale_items;")
    await connection.query("DELETE FROM sales;")
    await connection.query("DELETE FROM products;")
    await connection.query("DELETE FROM users;")
    await connection.query("DELETE FROM roles;")
    await connection.query("DELETE FROM reports;")
    await connection.query("ALTER TABLE activity_log AUTO_INCREMENT = 1;")
    await connection.query("ALTER TABLE commissions AUTO_INCREMENT = 1;")
    await connection.query("ALTER TABLE repairs AUTO_INCREMENT = 1;")
    await connection.query("ALTER TABLE sale_items AUTO_INCREMENT = 1;")
    await connection.query("ALTER TABLE sales AUTO_INCREMENT = 1;")
    await connection.query("ALTER TABLE products AUTO_INCREMENT = 1;")
    await connection.query("ALTER TABLE users AUTO_INCREMENT = 1;")
    await connection.query("ALTER TABLE roles AUTO_INCREMENT = 1;")
    await connection.query("ALTER TABLE reports AUTO_INCREMENT = 1;")
    await connection.query("SET FOREIGN_KEY_CHECKS = 1;")
    await connection.query(`
      INSERT INTO roles (name) VALUES
        ('Admin'),
        ('Cashier');
    `)
    console.log("✅ All tables cleared successfully. Only base roles remain.")
  } catch (error) {
    console.error("❌ Failed to clear tables:", error)
    throw error
  } finally {
    if (connection) connection.release()
  }
}

// Helper function to log activities
async function logActivity(activityData) {
  try {
    const { userId, userName, role, action, details } = activityData
    await pool.query("INSERT INTO activity_log (user_id, user_name, role, action, details) VALUES (?, ?, ?, ?, ?)", [
      userId,
      userName,
      role,
      action,
      details,
    ])
  } catch (error) {
    console.error("Error logging activity:", error)
  }
}

// --- PRODUCTS FUNCTIONS ---
async function getAllProducts() {
  try {
    const [rows] = await pool.query("SELECT * FROM products WHERE is_active = 1 ORDER BY name")
    return { success: true, products: rows }
  } catch (error) {
    console.error("Error getting products:", error)
    return { success: false, message: "Failed to get products" }
  }
}

async function getProductById(id) {
  try {
    const [rows] = await pool.query("SELECT * FROM products WHERE id = ?", [id])
    if (rows.length === 0) {
      return { success: false, message: "Product not found" }
    }
    return { success: true, product: rows[0] }
  } catch (error) {
    console.error("Error getting product:", error)
    return { success: false, message: "Failed to get product" }
  }
}

async function createProduct(productData) {
  try {
    const { name, category, price, stock } = productData
    const [result] = await pool.query("INSERT INTO products (name, category, price, stock) VALUES (?, ?, ?, ?)", [
      name,
      category,
      price,
      stock,
    ])
    return { success: true, productId: result.insertId }
  } catch (error) {
    console.error("Error creating product:", error)
    return { success: false, message: "Failed to create product" }
  }
}

async function updateProduct(productData) {
  try {
    const { id, name, category, price, stock } = productData
    const [result] = await pool.query("UPDATE products SET name = ?, category = ?, price = ?, stock = ? WHERE id = ?", [
      name,
      category,
      price,
      stock,
      id,
    ])
    if (result.affectedRows === 0) {
      return { success: false, message: "Product not found" }
    }
    return { success: true }
  } catch (error) {
    console.error("Error updating product:", error)
    return { success: false, message: "Failed to update product" }
  }
}

async function deleteProduct(id) {
  try {
    const [result] = await pool.query("UPDATE products SET is_active = 0 WHERE id = ?", [id])
    if (result.affectedRows === 0) {
      return { success: false, message: "Product not found" }
    }
    return { success: true }
  } catch (error) {
    console.error("Error deleting product:", error)
    return { success: false, message: "Failed to delete product" }
  }
}

// Add after the existing product functions
async function getLowStockProducts() {
  try {
    const [rows] = await pool.query(`
      SELECT * FROM products 
      WHERE is_active = 1 AND stock <= low_stock_threshold 
      ORDER BY stock ASC
    `)
    return { success: true, products: rows }
  } catch (error) {
    console.error("Error getting low stock products:", error)
    return { success: false, message: "Failed to get low stock products" }
  }
}

async function adjustProductStock(adjustmentData) {
  try {
    const { product_id, adjustment_type, quantity, reason, user_id } = adjustmentData

    const connection = await pool.getConnection()
    await connection.beginTransaction()

    try {
      // Get current stock
      const [product] = await connection.query("SELECT stock, name FROM products WHERE id = ?", [product_id])
      if (product.length === 0) {
        throw new Error("Product not found")
      }

      const currentStock = product[0].stock
      const productName = product[0].name
      let newStock

      if (adjustment_type === "add") {
        newStock = currentStock + quantity
      } else if (adjustment_type === "subtract") {
        newStock = Math.max(0, currentStock - quantity)
      } else {
        newStock = quantity // direct set
      }

      // Update product stock
      await connection.query("UPDATE products SET stock = ? WHERE id = ?", [newStock, product_id])

      // Log the adjustment
      await connection.query(
        `
        INSERT INTO activity_log (user_id, user_name, role, action, details) 
        VALUES (?, ?, ?, ?, ?)
      `,
        [
          user_id,
          "System",
          "Admin",
          "Stock Adjustment",
          `${productName}: ${currentStock} → ${newStock} (${adjustment_type}: ${quantity}) - ${reason}`,
        ],
      )

      await connection.commit()
      return { success: true }
    } catch (error) {
      await connection.rollback()
      throw error
    } finally {
      connection.release()
    }
  } catch (error) {
    console.error("Error adjusting product stock:", error)
    return { success: false, message: "Failed to adjust stock" }
  }
}

// --- SALES FUNCTIONS ---
async function getAllSales() {
  try {
    const [rows] = await pool.query(`
      SELECT s.*, u.name as cashier_name 
      FROM sales s 
      LEFT JOIN users u ON s.cashier_id = u.id 
      ORDER BY s.date DESC
    `)
    return { success: true, sales: rows }
  } catch (error) {
    console.error("Error getting sales:", error)
    return { success: false, message: "Failed to get sales" }
  }
}

async function getSaleById(id) {
  try {
    const [sales] = await pool.query(
      `
      SELECT s.*, u.name as cashier_name 
      FROM sales s 
      LEFT JOIN users u ON s.cashier_id = u.id 
      WHERE s.id = ?
    `,
      [id],
    )

    if (sales.length === 0) {
      return { success: false, message: "Sale not found" }
    }

    const [items] = await pool.query(
      `
      SELECT si.*, p.name as product_name 
      FROM sale_items si 
      JOIN products p ON si.product_id = p.id 
      WHERE si.sale_id = ?
    `,
      [id],
    )

    const sale = sales[0]
    sale.items = items

    return { success: true, sale }
  } catch (error) {
    console.error("Error getting sale:", error)
    return { success: false, message: "Failed to get sale" }
  }
}

async function createSale(saleData) {
  try {
    const { cashier_id, client_name, total_amount, payment_method, items } = saleData

    // Start transaction
    const connection = await pool.getConnection()
    await connection.beginTransaction()

    try {
      // Create sale record
      const [saleResult] = await connection.query(
        `
        INSERT INTO sales (cashier_id, client_name, total_amount, payment_method) 
        VALUES (?, ?, ?, ?)
      `,
        [cashier_id, client_name, total_amount, payment_method],
      )

      const saleId = saleResult.insertId

      // Create sale items
      for (const item of items) {
        await connection.query(
          `
          INSERT INTO sale_items (sale_id, product_id, quantity, unit_price, total_price) 
          VALUES (?, ?, ?, ?, ?)
        `,
          [saleId, item.product_id, item.quantity, item.unit_price, item.total_price],
        )

        // Update product stock
        await connection.query(
          `
          UPDATE products SET stock = stock - ? WHERE id = ?
        `,
          [item.quantity, item.product_id],
        )
      }

      await connection.commit()

      // Log activity
      await logActivity({
        userId: cashier_id,
        userName: "Cashier",
        role: "Cashier",
        action: "Created sale",
        details: `Total: ₱${total_amount.toFixed(2)}, Client: ${client_name || "Walk-in"}`,
      })

      return { success: true, saleId }
    } catch (error) {
      await connection.rollback()
      throw error
    } finally {
      connection.release()
    }
  } catch (error) {
    console.error("Error creating sale:", error)
    return { success: false, message: "Failed to create sale" }
  }
}

// --- REPAIRS FUNCTIONS ---
async function getAllRepairs() {
  try {
    const [rows] = await pool.query(`
      SELECT r.*, u.name as cashier_name 
      FROM repairs r 
      LEFT JOIN users u ON r.cashier_id = u.id 
      ORDER BY r.date DESC
    `)
    return { success: true, repairs: rows }
  } catch (error) {
    console.error("Error getting repairs:", error)
    return { success: false, message: "Failed to get repairs" }
  }
}

async function getRepairById(id) {
  try {
    const [rows] = await pool.query(
      `
      SELECT r.*, u.name as cashier_name 
      FROM repairs r 
      LEFT JOIN users u ON r.cashier_id = u.id 
      WHERE r.id = ?
    `,
      [id],
    )
    if (rows.length === 0) {
      return { success: false, message: "Repair not found" }
    }
    return { success: true, repair: rows[0] }
  } catch (error) {
    console.error("Error getting repair:", error)
    return { success: false, message: "Failed to get repair" }
  }
}

async function createRepair(repairData) {
  try {
    const {
      device_model,
      client_name,
      client_phone,
      issue_description,
      parts_used,
      service_fee,
      commission_amount,
      status,
      cashier_id,
    } = repairData

    // Start transaction
    const connection = await pool.getConnection()
    await connection.beginTransaction()

    try {
      // Create repair record
      const [repairResult] = await connection.query(
        `
        INSERT INTO repairs (device_model, client_name, client_phone, issue_description, parts_used, service_fee, commission_amount, status, cashier_id) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `,
        [
          device_model,
          client_name,
          client_phone,
          issue_description,
          parts_used,
          service_fee,
          commission_amount,
          status,
          cashier_id,
        ],
      )

      const repairId = repairResult.insertId

      // Create commission record if commission amount > 0
      if (commission_amount > 0) {
        await connection.query(
          `
          INSERT INTO commissions (repair_id, cashier_id, commission_amount, status) 
          VALUES (?, ?, ?, 'Unpaid')
        `,
          [repairId, cashier_id, commission_amount],
        )
      }

      await connection.commit()

      // Log activity
      await logActivity({
        userId: cashier_id,
        userName: "Cashier", // You might want to get the actual name
        role: "Cashier",
        action: "Created repair job",
        details: `Device: ${device_model}, Client: ${client_name}`,
      })

      return { success: true, repairId }
    } catch (error) {
      await connection.rollback()
      throw error
    } finally {
      connection.release()
    }
  } catch (error) {
    console.error("Error creating repair:", error)
    return { success: false, message: "Failed to create repair" }
  }
}

async function updateRepair(repairData) {
  try {
    const {
      id,
      device_model,
      client_name,
      client_phone,
      issue_description,
      parts_used,
      service_fee,
      commission_amount,
      status,
    } = repairData
    const [result] = await pool.query(
      `
      UPDATE repairs 
      SET device_model = ?, client_name = ?, client_phone = ?, issue_description = ?, parts_used = ?, service_fee = ?, commission_amount = ?, status = ?
      WHERE id = ?
    `,
      [
        device_model,
        client_name,
        client_phone,
        issue_description,
        parts_used,
        service_fee,
        commission_amount,
        status,
        id,
      ],
    )

    if (result.affectedRows === 0) {
      return { success: false, message: "Repair not found" }
    }

    return { success: true }
  } catch (error) {
    console.error("Error updating repair:", error)
    return { success: false, message: "Failed to update repair" }
  }
}

async function deleteRepair(id) {
  try {
    const [result] = await pool.query("DELETE FROM repairs WHERE id = ?", [id])
    if (result.affectedRows === 0) {
      return { success: false, message: "Repair not found" }
    }
    return { success: true }
  } catch (error) {
    console.error("Error deleting repair:", error)
    return { success: false, message: "Failed to delete repair" }
  }
}

// --- COMMISSIONS FUNCTIONS ---
async function getAllCommissions() {
  try {
    const [rows] = await pool.query(`
      SELECT c.*, u.name as cashier_name, r.device_model as repair_job, r.client_name
      FROM commissions c 
      LEFT JOIN users u ON c.cashier_id = u.id 
      LEFT JOIN repairs r ON c.repair_id = r.id
      ORDER BY c.date DESC
    `)
    return { success: true, commissions: rows }
  } catch (error) {
    console.error("Error getting commissions:", error)
    return { success: false, message: "Failed to get commissions" }
  }
}

async function getCashierCommissions(cashierId) {
  try {
    const [rows] = await pool.query(
      `
      SELECT c.*, r.device_model as repair_job, r.client_name
      FROM commissions c 
      LEFT JOIN repairs r ON c.repair_id = r.id
      WHERE c.cashier_id = ?
      ORDER BY c.date DESC
    `,
      [cashierId],
    )
    return { success: true, commissions: rows }
  } catch (error) {
    console.error("Error getting cashier commissions:", error)
    return { success: false, message: "Failed to get commissions" }
  }
}

async function getCommissionById(id) {
  try {
    const [rows] = await pool.query(
      `
      SELECT c.*, u.name as cashier_name, r.device_model as repair_job, r.client_name
      FROM commissions c 
      LEFT JOIN users u ON c.cashier_id = u.id 
      LEFT JOIN repairs r ON c.repair_id = r.id
      WHERE c.id = ?
    `,
      [id],
    )
    if (rows.length === 0) {
      return { success: false, message: "Commission not found" }
    }
    return { success: true, commission: rows[0] }
  } catch (error) {
    console.error("Error getting commission:", error)
    return { success: false, message: "Failed to get commission" }
  }
}

async function createCommission(commissionData) {
  try {
    const { repair_id, cashier_id, commission_amount } = commissionData
    const [result] = await pool.query(
      `
      INSERT INTO commissions (repair_id, cashier_id, commission_amount, status) 
      VALUES (?, ?, ?, 'Unpaid')
    `,
      [repair_id, cashier_id, commission_amount],
    )

    return { success: true, commissionId: result.insertId }
  } catch (error) {
    console.error("Error creating commission:", error)
    return { success: false, message: "Failed to create commission" }
  }
}

async function updateCommissionPayment(paymentData) {
  try {
    const { id, payment_date, payment_method, notes } = paymentData
    const [result] = await pool.query(
      `
      UPDATE commissions 
      SET status = 'Paid', payment_date = ?, payment_method = ?, notes = ?
      WHERE id = ?
    `,
      [payment_date, payment_method, notes, id],
    )

    if (result.affectedRows === 0) {
      return { success: false, message: "Commission not found" }
    }

    // Log activity
    await logActivity({
      userId: 1, // Admin user ID
      userName: "Admin",
      role: "Admin",
      action: "Commission Payment Recorded",
      details: `Commission ID: ${id}, Payment Date: ${payment_date}`,
    })

    return { success: true }
  } catch (error) {
    console.error("Error updating commission payment:", error)
    return { success: false, message: "Failed to update commission payment" }
  }
}

// --- REPORTS FUNCTIONS ---
async function getCashiers() {
  try {
    const [rows] = await pool.query(`
      SELECT id, name FROM users 
      WHERE role_id = (SELECT id FROM roles WHERE name = 'Cashier')
      ORDER BY name
    `)
    return { success: true, cashiers: rows }
  } catch (error) {
    console.error("Error getting cashiers:", error)
    return { success: false, message: "Failed to get cashiers" }
  }
}

async function generateSalesReport(filters) {
  try {
    let whereClause = "WHERE 1=1"
    const params = []

    if (filters.dateFrom) {
      whereClause += " AND DATE(s.date) >= ?"
      params.push(filters.dateFrom)
    }
    if (filters.dateTo) {
      whereClause += " AND DATE(s.date) <= ?"
      params.push(filters.dateTo)
    }
    if (filters.cashierId) {
      whereClause += " AND s.cashier_id = ?"
      params.push(filters.cashierId)
    }

    const [sales] = await pool.query(
      `
      SELECT 
        DATE_FORMAT(s.date, '%Y-%m-%d') as date,
        u.name as cashier_name,
        s.client_name,
        s.total_amount,
        s.payment_method,
        COUNT(si.id) as items_count
      FROM sales s
      LEFT JOIN users u ON s.cashier_id = u.id
      LEFT JOIN sale_items si ON s.id = si.sale_id
      ${whereClause}
      GROUP BY s.id
      ORDER BY s.date DESC
    `,
      params,
    )

    // Calculate summary
    const totalSales = sales.reduce((sum, sale) => sum + Number.parseFloat(sale.total_amount), 0)
    const totalTransactions = sales.length
    const avgTransactionValue = totalTransactions > 0 ? totalSales / totalTransactions : 0

    const summary = {
      "Total Sales": `₱${totalSales.toFixed(2)}`,
      "Total Transactions": totalTransactions,
      "Average Transaction": `₱${avgTransactionValue.toFixed(2)}`,
      "Date Range": `${filters.dateFrom || "All"} to ${filters.dateTo || "All"}`,
    }

    return { success: true, report: { data: sales, summary } }
  } catch (error) {
    console.error("Error generating sales report:", error)
    return { success: false, message: "Failed to generate sales report" }
  }
}

async function generateRepairReport(filters) {
  try {
    let whereClause = "WHERE 1=1"
    const params = []

    if (filters.dateFrom) {
      whereClause += " AND DATE(r.date) >= ?"
      params.push(filters.dateFrom)
    }
    if (filters.dateTo) {
      whereClause += " AND DATE(r.date) <= ?"
      params.push(filters.dateTo)
    }
    if (filters.status) {
      whereClause += " AND r.status = ?"
      params.push(filters.status)
    }

    const [repairs] = await pool.query(
      `
      SELECT 
        DATE_FORMAT(r.date, '%Y-%m-%d') as date,
        u.name as cashier_name,
        r.client_name,
        r.device_model,
        r.issue_description,
        r.service_fee,
        r.commission_amount,
        r.status
      FROM repairs r
      LEFT JOIN users u ON r.cashier_id = u.id
      ${whereClause}
      ORDER BY r.date DESC
    `,
      params,
    )

    // Calculate summary
    const totalRepairs = repairs.length
    const totalServiceFees = repairs.reduce((sum, repair) => sum + Number.parseFloat(repair.service_fee), 0)
    const totalCommissions = repairs.reduce((sum, repair) => sum + Number.parseFloat(repair.commission_amount), 0)
    const completedRepairs = repairs.filter((r) => r.status === "Completed" || r.status === "Released").length

    const summary = {
      "Total Repairs": totalRepairs,
      "Completed Repairs": completedRepairs,
      "Total Service Fees": `₱${totalServiceFees.toFixed(2)}`,
      "Total Commissions": `₱${totalCommissions.toFixed(2)}`,
      "Completion Rate": `${totalRepairs > 0 ? ((completedRepairs / totalRepairs) * 100).toFixed(1) : 0}%`,
    }

    return { success: true, report: { data: repairs, summary } }
  } catch (error) {
    console.error("Error generating repair report:", error)
    return { success: false, message: "Failed to generate repair report" }
  }
}

async function generateCommissionReport(filters) {
  try {
    let whereClause = "WHERE 1=1"
    const params = []

    if (filters.dateFrom) {
      whereClause += " AND DATE(c.date) >= ?"
      params.push(filters.dateFrom)
    }
    if (filters.dateTo) {
      whereClause += " AND DATE(c.date) <= ?"
      params.push(filters.dateTo)
    }
    if (filters.status) {
      whereClause += " AND c.status = ?"
      params.push(filters.status)
    }

    const [commissions] = await pool.query(
      `
      SELECT 
        DATE_FORMAT(c.date, '%Y-%m-%d') as date,
        u.name as cashier_name,
        r.device_model as repair_job,
        r.client_name,
        c.commission_amount,
        c.status,
        DATE_FORMAT(c.payment_date, '%Y-%m-%d') as payment_date,
        c.payment_method
      FROM commissions c
      LEFT JOIN users u ON c.cashier_id = u.id
      LEFT JOIN repairs r ON c.repair_id = r.id
      ${whereClause}
      ORDER BY c.date DESC
    `,
      params,
    )

    // Calculate summary
    const totalCommissions = commissions.reduce((sum, comm) => sum + Number.parseFloat(comm.commission_amount), 0)
    const paidCommissions = commissions
      .filter((c) => c.status === "Paid")
      .reduce((sum, comm) => sum + Number.parseFloat(comm.commission_amount), 0)
    const unpaidCommissions = totalCommissions - paidCommissions
    const totalTransactions = commissions.length

    const summary = {
      "Total Commissions": `₱${totalCommissions.toFixed(2)}`,
      "Paid Commissions": `₱${paidCommissions.toFixed(2)}`,
      "Unpaid Commissions": `₱${unpaidCommissions.toFixed(2)}`,
      "Total Transactions": totalTransactions,
      "Payment Rate": `${totalCommissions > 0 ? ((paidCommissions / totalCommissions) * 100).toFixed(1) : 0}%`,
    }

    return { success: true, report: { data: commissions, summary } }
  } catch (error) {
    console.error("Error generating commission report:", error)
    return { success: false, message: "Failed to generate commission report" }
  }
}

async function generateInventoryReport(filters) {
  try {
    let whereClause = "WHERE p.is_active = 1"
    const params = []

    if (filters.category) {
      whereClause += " AND p.category = ?"
      params.push(filters.category)
    }

    let query = ""
    if (filters.type === "low_stock") {
      query = `
        SELECT 
          p.name,
          p.category,
          p.price,
          p.stock,
          p.low_stock_threshold,
          CASE 
            WHEN p.stock <= p.low_stock_threshold THEN 'Low Stock'
            ELSE 'In Stock'
          END as stock_status
        FROM products p
        ${whereClause}
        ORDER BY p.stock ASC
      `
    } else if (filters.type === "popular_items") {
      query = `
        SELECT 
          p.name,
          p.category,
          p.price,
          p.stock,
          COUNT(si.id) as times_sold,
          SUM(si.quantity) as total_quantity_sold
        FROM products p
        LEFT JOIN sale_items si ON p.id = si.product_id
        ${whereClause}
        GROUP BY p.id
        HAVING times_sold > 0
        ORDER BY times_sold DESC
      `
    } else {
      query = `
        SELECT 
          p.name,
          p.category,
          p.price,
          p.stock,
          p.low_stock_threshold,
          CASE 
            WHEN p.stock <= p.low_stock_threshold THEN 'Low Stock'
            ELSE 'In Stock'
          END as stock_status
        FROM products p
        ${whereClause}
        ORDER BY p.name
      `
    }

    const [inventory] = await pool.query(query, params)

    // Calculate summary
    const totalItems = inventory.length
    const lowStockItems = inventory.filter((item) => item.stock_status === "Low Stock").length
    const totalValue = inventory.reduce(
      (sum, item) => sum + Number.parseFloat(item.price) * Number.parseInt(item.stock),
      0,
    )

    const summary = {
      "Total Items": totalItems,
      "Low Stock Items": lowStockItems,
      "Total Inventory Value": `₱${totalValue.toFixed(2)}`,
      "Report Type": filters.type.replace("_", " ").toUpperCase(),
    }

    return { success: true, report: { data: inventory, summary } }
  } catch (error) {
    console.error("Error generating inventory report:", error)
    return { success: false, message: "Failed to generate inventory report" }
  }
}

// --- USER MANAGEMENT FUNCTIONS ---
async function getAllUsers() {
  try {
    const [rows] = await pool.query(`
      SELECT u.*, r.name as role_name
      FROM users u
      LEFT JOIN roles r ON u.role_id = r.id
      ORDER BY u.name
    `)
    return { success: true, users: rows }
  } catch (error) {
    console.error("Error getting users:", error)
    return { success: false, message: "Failed to get users" }
  }
}

async function getUserById(id) {
  try {
    const [rows] = await pool.query(
      `
      SELECT u.*, r.name as role_name
      FROM users u
      LEFT JOIN roles r ON u.role_id = r.id
      WHERE u.id = ?
    `,
      [id],
    )
    if (rows.length === 0) {
      return { success: false, message: "User not found" }
    }
    return { success: true, user: rows[0] }
  } catch (error) {
    console.error("Error getting user:", error)
    return { success: false, message: "Failed to get user" }
  }
}

async function createUser(userData) {
  try {
    const { name, username, email, password, role, status } = userData

    // Check if username already exists
    const [existingUser] = await pool.query("SELECT id FROM users WHERE username = ?", [username])
    if (existingUser.length > 0) {
      return { success: false, message: "Username already exists" }
    }

    // Check if email already exists
    const [existingEmail] = await pool.query("SELECT id FROM users WHERE email = ?", [email])
    if (existingEmail.length > 0) {
      return { success: false, message: "Email already exists" }
    }

    // Get role ID
    const [roleResult] = await pool.query("SELECT id FROM roles WHERE name = ?", [role])
    if (roleResult.length === 0) {
      return { success: false, message: "Invalid role" }
    }
    const roleId = roleResult[0].id

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10)

    const [result] = await pool.query(
      `
      INSERT INTO users (name, username, email, password, role_id, status) 
      VALUES (?, ?, ?, ?, ?, ?)
    `,
      [name, username, email, hashedPassword, roleId, status],
    )

    // Log activity
    await logActivity({
      userId: 1, // Admin user ID
      userName: "Admin",
      role: "Admin",
      action: "Created user",
      details: `Username: ${username}, Role: ${role}`,
    })

    return { success: true, userId: result.insertId }
  } catch (error) {
    console.error("Error creating user:", error)
    return { success: false, message: "Failed to create user" }
  }
}

async function updateUser(userData) {
  try {
    const { id, name, username, email, password, role, status } = userData

    // Check if username already exists (excluding current user)
    const [existingUser] = await pool.query("SELECT id FROM users WHERE username = ? AND id != ?", [username, id])
    if (existingUser.length > 0) {
      return { success: false, message: "Username already exists" }
    }

    // Check if email already exists (excluding current user)
    const [existingEmail] = await pool.query("SELECT id FROM users WHERE email = ? AND id != ?", [email, id])
    if (existingEmail.length > 0) {
      return { success: false, message: "Email already exists" }
    }

    // Get role ID
    const [roleResult] = await pool.query("SELECT id FROM roles WHERE name = ?", [role])
    if (roleResult.length === 0) {
      return { success: false, message: "Invalid role" }
    }
    const roleId = roleResult[0].id

    let query = `
      UPDATE users 
      SET name = ?, username = ?, email = ?, role_id = ?, status = ?, updated_at = NOW()
      WHERE id = ?
    `
    let params = [name, username, email, roleId, status, id]

    // Include password update if provided
    if (password) {
      const hashedPassword = await bcrypt.hash(password, 10)
      query = `
        UPDATE users 
        SET name = ?, username = ?, email = ?, password = ?, role_id = ?, status = ?, updated_at = NOW()
        WHERE id = ?
      `
      params = [name, username, email, hashedPassword, roleId, status, id]
    }

    const [result] = await pool.query(query, params)

    if (result.affectedRows === 0) {
      return { success: false, message: "User not found" }
    }

    // Log activity
    await logActivity({
      userId: 1, // Admin user ID
      userName: "Admin",
      role: "Admin",
      action: "Updated user",
      details: `Username: ${username}, Role: ${role}`,
    })

    return { success: true }
  } catch (error) {
    console.error("Error updating user:", error)
    return { success: false, message: "Failed to update user" }
  }
}

async function deleteUser(id) {
  try {
    // Prevent deletion of the main admin user (ID 1)
    if (id === 1) {
      return { success: false, message: "Cannot delete the main admin user" }
    }

    const [result] = await pool.query("DELETE FROM users WHERE id = ?", [id])
    if (result.affectedRows === 0) {
      return { success: false, message: "User not found" }
    }

    // Log activity
    await logActivity({
      userId: 1, // Admin user ID
      userName: "Admin",
      role: "Admin",
      action: "Deleted user",
      details: `User ID: ${id}`,
    })

    return { success: true }
  } catch (error) {
    console.error("Error deleting user:", error)
    return { success: false, message: "Failed to delete user" }
  }
}

module.exports = {
  pool,
  initializeDatabase,
  clearAllTables,
  logActivity,
  getAllProducts,
  getProductById,
  createProduct,
  updateProduct,
  deleteProduct,
  getLowStockProducts,
  adjustProductStock,
  getAllSales,
  getSaleById,
  createSale,
  getAllRepairs,
  getRepairById,
  createRepair,
  updateRepair,
  deleteRepair,
  getAllCommissions,
  getCashierCommissions,
  getCommissionById,
  createCommission,
  updateCommissionPayment,
  getCashiers,
  generateSalesReport,
  generateRepairReport,
  generateCommissionReport,
  generateInventoryReport,
  getAllUsers,
  getUserById,
  createUser,
  updateUser,
  deleteUser,
}
