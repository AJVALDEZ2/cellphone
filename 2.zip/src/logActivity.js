const { pool } = require("./db");

/**
 * Log a user/admin action
 * @param {Object} params
 * @param {number} params.userId
 * @param {string} params.userName
 * @param {string} params.role
 * @param {string} params.email
 * @param {string} params.action
 * @param {string} [params.details]
 */
async function logActivity({ userId, userName, role, email, action, details }) {
  try {
    await pool.query(
      "INSERT INTO activity_log (user_id, user_name, role, email, action, details) VALUES (?, ?, ?, ?, ?, ?)",
      [userId, userName, role, email, action, details || null]
    );
  } catch (err) {
    console.error("Activity log failed:", err);
  }
}

module.exports = { logActivity };
