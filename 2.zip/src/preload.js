const { contextBridge, ipcRenderer } = require("electron")

contextBridge.exposeInMainWorld("jobAPI", {
  // Auth
  signup: (data) => ipcRenderer.invoke("signup", data),
  login: (data) => ipcRenderer.invoke("login", data),
  logout: () => ipcRenderer.send("logout"),
  getCurrentSession: () => ipcRenderer.invoke("getCurrentSession"),
  getRoles: () => ipcRenderer.invoke("getRoles"),

  // Student borrow requests
  requestBorrow: (bookId) => ipcRenderer.invoke("student:requestBorrow", bookId),
  getMyBorrowRequests: () => ipcRenderer.invoke("student:getMyBorrowRequests"),
  returnBook: (requestId) => ipcRenderer.invoke("student:returnBook", requestId),

  // Admin & Cataloger functions
  admin: {
    getUsers: () => ipcRenderer.invoke("admin:getUsers"),
    getUserById: (userId) => ipcRenderer.invoke("admin:getUserById", userId),
    updateUser: (userData) => ipcRenderer.invoke("admin:updateUser", userData),
    deleteUser: (userId) => ipcRenderer.invoke("admin:deleteUser", userId),
    createUser: (userData) => ipcRenderer.invoke("admin:createUser", userData),
    getDashboardStats: () => ipcRenderer.invoke("admin:getDashboardStats"),
    getActivityLog: () => ipcRenderer.invoke("admin:getActivityLog"),

    // Books management
    getBooks: () => ipcRenderer.invoke("admin:getBooks"),
    getBookById: (bookId) => ipcRenderer.invoke("admin:getBookById", bookId),
    createBook: (bookData) => ipcRenderer.invoke("admin:createBook", bookData),
    updateBook: (bookData) => ipcRenderer.invoke("admin:updateBook", bookData),
    deleteBook: (bookId) => ipcRenderer.invoke("admin:deleteBook", bookId),

    // Categories management
    getCategories: () => ipcRenderer.invoke("admin:getCategories"),
    createCategory: (categoryData) => ipcRenderer.invoke("admin:createCategory", categoryData),
    updateCategory: (categoryData) => ipcRenderer.invoke("admin:updateCategory", categoryData),
    deleteCategory: (categoryId) => ipcRenderer.invoke("admin:deleteCategory", categoryId),

    // Inventory management
    getInventory: () => ipcRenderer.invoke("admin:getInventory"),
    updateInventory: (inventoryData) => ipcRenderer.invoke("admin:updateInventory", inventoryData),

    // Damages management
    getDamages: () => ipcRenderer.invoke("admin:getDamages"),
    getDamageById: (damageId) => ipcRenderer.invoke("admin:getDamageById", damageId),
    createDamageReport: (damageData) => ipcRenderer.invoke("admin:createDamageReport", damageData),
    updateDamageStatus: (damageId, status) => ipcRenderer.invoke("admin:updateDamageStatus", damageId, status),

    // Reports
    generateReport: (reportType) => ipcRenderer.invoke("admin:generateReport", reportType),

    // Borrow Requests
    getBorrowRequests: () => ipcRenderer.invoke("admin:getBorrowRequests"),
    approveBorrowRequest: (data) => ipcRenderer.invoke("admin:approveBorrowRequest", data),
    rejectBorrowRequest: (data) => ipcRenderer.invoke("admin:rejectBorrowRequest", data),

    // Optional - for clearing database
    clearDatabase: () => ipcRenderer.invoke("admin:clearDatabase"),
  },

  // Cataloger: use the same as admin for simplicity, can be split later if needed
  cataloger: {
    getBooks: () => ipcRenderer.invoke("admin:getBooks"),
    getBookById: (bookId) => ipcRenderer.invoke("admin:getBookById", bookId),
    createBook: (bookData) => ipcRenderer.invoke("admin:createBook", bookData),
    updateBook: (bookData) => ipcRenderer.invoke("admin:updateBook", bookData),
    deleteBook: (bookId) => ipcRenderer.invoke("admin:deleteBook", bookId),
    getCategories: () => ipcRenderer.invoke("admin:getCategories"),
    createCategory: (categoryData) => ipcRenderer.invoke("admin:createCategory", categoryData),
    updateCategory: (categoryData) => ipcRenderer.invoke("admin:updateCategory", categoryData),
    deleteCategory: (categoryId) => ipcRenderer.invoke("admin:deleteCategory", categoryId),
    getInventory: () => ipcRenderer.invoke("admin:getInventory"),
    updateInventory: (inventoryData) => ipcRenderer.invoke("admin:updateInventory", inventoryData),
    // Assign Recommendations functionality could go here if needed
  },

  // Navigation helpers
  navigation: {
    goToPage: (page) => {
      window.location.href = page
    },
  },
})
