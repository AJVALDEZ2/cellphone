// Cashier dashboard functionality for Cellphone Repair Shop
let currentUserRole = null
let showNotification = null
let formatDateTime = null

async function fetchSession() {
  const session = await window.jobAPI.getCurrentSession()
  currentUserRole = session?.role || null
}

// --- SALES MODULE ---
let cart = []
let productsList = []

async function fetchProductsForSales() {
  try {
    const res = await window.jobAPI.getProducts()
    productsList = res.products || []
    const select = document.getElementById("productSelect")
    select.innerHTML = productsList
      .map(
        (p) =>
          `<option value="${p.id}" data-price="${p.price}">${p.name} (${p.category}) - ₱${p.price.toFixed(2)}</option>`,
      )
      .join("")
  } catch (e) {
    showNotification("Failed to load products", "error")
  }
}

function updateCartTable() {
  const tbody = document.getElementById("cartTableBody")
  tbody.innerHTML = ""
  let total = 0
  cart.forEach((item, idx) => {
    const tr = document.createElement("tr")
    tr.innerHTML = `
      <td>${item.name}</td>
      <td>${item.quantity}</td>
      <td>₱${item.unit_price.toFixed(2)}</td>
      <td>₱${item.total_price.toFixed(2)}</td>
      <td><button class='btn-danger btn-sm' onclick='removeCartItem(${idx})'><i class='fas fa-trash'></i></button></td>
    `
    tbody.appendChild(tr)
    total += item.total_price
  })
  document.getElementById("salesTotal").textContent = total.toFixed(2)
}

window.removeCartItem = (idx) => {
  cart.splice(idx, 1)
  updateCartTable()
}

document.getElementById("addToCartBtn").onclick = () => {
  const productId = Number.parseInt(document.getElementById("productSelect").value)
  const qty = Number.parseInt(document.getElementById("productQty").value)
  if (!productId || isNaN(qty) || qty < 1) {
    showNotification("Select a product and enter a valid quantity", "error")
    return
  }
  const product = productsList.find((p) => p.id === productId)
  if (!product) {
    showNotification("Product not found", "error")
    return
  }
  // Check if already in cart
  const existing = cart.find((item) => item.product_id === productId)
  if (existing) {
    existing.quantity += qty
    existing.total_price = existing.quantity * existing.unit_price
  } else {
    cart.push({
      product_id: product.id,
      name: product.name,
      quantity: qty,
      unit_price: product.price,
      total_price: qty * product.price,
    })
  }
  updateCartTable()
}

document.getElementById("salesForm").onsubmit = async (e) => {
  e.preventDefault()
  if (cart.length === 0) {
    showNotification("Cart is empty", "error")
    return
  }
  const client_name = document.getElementById("clientName").value.trim()
  const payment_method = document.getElementById("paymentMethod").value
  const total_amount = Number.parseFloat(document.getElementById("salesTotal").textContent)
  try {
    const res = await window.jobAPI.createSale({
      cashier_id: window.currentUserId, // Set this from session if available
      client_name,
      total_amount,
      payment_method,
      items: cart.map((item) => ({
        product_id: item.product_id,
        quantity: item.quantity,
        unit_price: item.unit_price,
        total_price: item.total_price,
      })),
    })
    if (res.success) {
      showNotification("Sale recorded", "success")
      cart = []
      updateCartTable()
      fetchSales()
      document.getElementById("salesForm").reset()
    } else {
      showNotification(res.message || "Failed to record sale", "error")
    }
  } catch (e) {
    showNotification("Failed to record sale", "error")
  }
}

// --- SALES LISTING ---
async function fetchSales() {
  try {
    const res = await window.jobAPI.getSales()
    renderSales(res.sales || [])
  } catch (e) {
    showNotification("Failed to load sales", "error")
  }
}

function renderSales(sales) {
  const tbody = document.getElementById("salesTableBody")
  tbody.innerHTML = ""
  if (!sales.length) {
    tbody.innerHTML = `<tr><td colspan='5' class='empty-state'>No sales found</td></tr>`
    return
  }
  sales.forEach((sale) => {
    const tr = document.createElement("tr")
    tr.innerHTML = `
      <td>${formatDateTime(sale.date)}</td>
      <td>${sale.client_name || "-"}</td>
      <td>₱${sale.total_amount.toFixed(2)}</td>
      <td>${sale.payment_method}</td>
      <td><button class='btn-info btn-sm' onclick='viewSaleDetails(${sale.id})'><i class='fas fa-eye'></i></button></td>
    `
    tbody.appendChild(tr)
  })
}

window.viewSaleDetails = async (id) => {
  try {
    const res = await window.jobAPI.getSaleById(id)
    if (res.success) {
      showSaleDetailsModal(res.sale)
    } else {
      showNotification(res.message || "Sale not found", "error")
    }
  } catch (e) {
    showNotification("Failed to load sale details", "error")
  }
}

function showSaleDetailsModal(sale) {
  const modal = document.getElementById("saleDetailsModal")
  const body = document.getElementById("saleDetailsBody")
  body.innerHTML = `
    <div><strong>Date:</strong> ${formatDateTime(sale.date)}</div>
    <div><strong>Client:</strong> ${sale.client_name || "-"}</div>
    <div><strong>Total:</strong> ₱${sale.total_amount.toFixed(2)}</div>
    <div><strong>Payment:</strong> ${sale.payment_method}</div>
    <div><strong>Items:</strong></div>
    <table class='table'><thead><tr><th>Product</th><th>Qty</th><th>Unit Price</th><th>Total</th></tr></thead><tbody>
      ${sale.items
        .map(
          (item) => `
        <tr>
          <td>${item.product_name}</td>
          <td>${item.quantity}</td>
          <td>₱${item.unit_price.toFixed(2)}</td>
          <td>₱${item.total_price.toFixed(2)}</td>
        </tr>
      `,
        )
        .join("")}
    </tbody></table>
  `
  modal.classList.remove("hidden")
}

document.getElementById("closeSaleDetailsModal").onclick = () => {
  document.getElementById("saleDetailsModal").classList.add("hidden")
}

// --- REPAIRS MODULE ---
async function fetchRepairs() {
  try {
    const res = await window.jobAPI.getRepairs()
    renderRepairs(res.repairs || [])
  } catch (e) {
    showNotification("Failed to load repairs", "error")
  }
}

function renderRepairs(repairs) {
  const tbody = document.getElementById("repairsTableBody")
  tbody.innerHTML = ""
  if (!repairs.length) {
    tbody.innerHTML = `<tr><td colspan='7' class='empty-state'>No repairs found</td></tr>`
    return
  }
  repairs.forEach((repair) => {
    const tr = document.createElement("tr")
    tr.innerHTML = `
      <td>${formatDateTime(repair.date)}</td>
      <td>${repair.client_name}</td>
      <td>${repair.device_model}</td>
      <td><span class="status-badge status-${repair.status.toLowerCase().replace(" ", "-")}">${repair.status}</span></td>
      <td>₱${repair.service_fee.toFixed(2)}</td>
      <td>₱${repair.commission_amount.toFixed(2)}</td>
      <td><button class='btn-info btn-sm' onclick='viewRepairDetails(${repair.id})'><i class='fas fa-eye'></i></button></td>
    `
    tbody.appendChild(tr)
  })
}

window.viewRepairDetails = async (id) => {
  try {
    const res = await window.jobAPI.getRepairById(id)
    if (res.success) {
      showRepairDetailsModal(res.repair)
    } else {
      showNotification(res.message || "Repair not found", "error")
    }
  } catch (e) {
    showNotification("Failed to load repair details", "error")
  }
}

function showRepairDetailsModal(repair) {
  const modal = document.getElementById("repairDetailsModal")
  const body = document.getElementById("repairDetailsBody")
  body.innerHTML = `
    <div><strong>Date:</strong> ${formatDateTime(repair.date)}</div>
    <div><strong>Client:</strong> ${repair.client_name}</div>
    <div><strong>Phone:</strong> ${repair.client_phone}</div>
    <div><strong>Device:</strong> ${repair.device_model}</div>
    <div><strong>Issue:</strong> ${repair.issue_description}</div>
    <div><strong>Parts Used:</strong> ${repair.parts_used || "-"}</div>
    <div><strong>Service Fee:</strong> ₱${repair.service_fee.toFixed(2)}</div>
    <div><strong>Commission:</strong> ₱${repair.commission_amount.toFixed(2)}</div>
    <div><strong>Status:</strong> <span class="status-badge status-${repair.status.toLowerCase()}">${repair.status}</span></div>
  `
  modal.classList.remove("hidden")
}

document.getElementById("closeRepairDetailsModal").onclick = () => {
  document.getElementById("repairDetailsModal").classList.add("hidden")
}

document.getElementById("repairForm").onsubmit = async (e) => {
  e.preventDefault()
  const formData = new FormData(e.target)
  const repairData = {
    device_model: formData.get("deviceModel"),
    client_name: formData.get("clientName"),
    client_phone: formData.get("clientPhone"),
    issue_description: formData.get("issueDescription"),
    parts_used: formData.get("partsUsed"),
    service_fee: Number.parseFloat(formData.get("serviceFee")),
    commission_amount: Number.parseFloat(formData.get("commissionAmount")),
    status: formData.get("status"),
    cashier_id: window.currentUserId, // Set this from session if available
  }
  try {
    const res = await window.jobAPI.createRepair(repairData)
    if (res.success) {
      showNotification("Repair job registered", "success")
      document.getElementById("repairForm").reset()
      fetchRepairs()
    } else {
      showNotification(res.message || "Failed to register repair", "error")
    }
  } catch (e) {
    showNotification("Failed to register repair", "error")
  }
}

// --- COMMISSIONS MODULE ---
async function fetchCashierCommissions() {
  try {
    const res = await window.jobAPI.getCashierCommissions()
    renderCashierCommissions(res.commissions || [])
    updateCashierCommissionStats(res.commissions || [])
  } catch (e) {
    showNotification("Failed to load commissions", "error")
  }
}

function renderCashierCommissions(commissions) {
  const tbody = document.getElementById("cashierCommissionsTableBody")
  tbody.innerHTML = ""
  if (!commissions.length) {
    tbody.innerHTML = `<tr><td colspan='6' class='empty-state'>No commissions found</td></tr>`
    return
  }
  commissions.forEach((commission) => {
    const tr = document.createElement("tr")
    tr.innerHTML = `
      <td>${formatDateTime(commission.date)}</td>
      <td>${commission.repair_job}</td>
      <td>${commission.client_name}</td>
      <td>₱${commission.commission_amount.toFixed(2)}</td>
      <td><span class="status-badge status-${commission.status.toLowerCase()}">${commission.status}</span></td>
      <td>${commission.payment_date ? formatDateTime(commission.payment_date) : "-"}</td>
    `
    tbody.appendChild(tr)
  })
}

function updateCashierCommissionStats(commissions) {
  const total = commissions.reduce((sum, c) => sum + Number.parseFloat(c.commission_amount), 0)
  const pending = commissions
    .filter((c) => c.status === "Unpaid")
    .reduce((sum, c) => sum + Number.parseFloat(c.commission_amount), 0)

  const now = new Date()
  const thisMonth = commissions
    .filter((c) => {
      const commissionDate = new Date(c.date)
      return commissionDate.getMonth() === now.getMonth() && commissionDate.getFullYear() === now.getFullYear()
    })
    .reduce((sum, c) => sum + Number.parseFloat(c.commission_amount), 0)

  document.getElementById("cashierTotalCommissions").textContent = `₱${total.toFixed(2)}`
  document.getElementById("cashierPendingCommissions").textContent = `₱${pending.toFixed(2)}`
  document.getElementById("cashierMonthlyCommissions").textContent = `₱${thisMonth.toFixed(2)}`
}

// Add cashier dashboard statistics
async function fetchCashierDashboardStats() {
  try {
    const [sales, repairs] = await Promise.all([window.jobAPI.getSales(), window.jobAPI.getRepairs()])

    updateCashierDashboardStats({
      sales: sales.sales || [],
      repairs: repairs.repairs || [],
    })
  } catch (error) {
    console.error("Failed to fetch cashier dashboard stats:", error)
  }
}

function updateCashierDashboardStats(data) {
  const today = new Date().toDateString()
  const todaySales = data.sales.filter((s) => new Date(s.date).toDateString() === today)
  const todayRevenue = todaySales.reduce((sum, s) => sum + Number.parseFloat(s.total_amount), 0)

  const myRepairs = data.repairs.filter((r) => r.cashier_id === window.currentUserId)
  const pendingRepairs = myRepairs.filter((r) => r.status === "Pending" || r.status === "In Progress").length

  // Update sales section if stats don't exist
  const salesSection = document.getElementById("salesSection")
  if (salesSection && !salesSection.querySelector(".cashier-stats")) {
    const statsHTML = `
      <div class="cashier-stats stats-grid mb-4">
        <div class="stat-card">
          <div class="stat-header">
            <h3>Today's Sales</h3>
            <div class="stat-icon users">
              <i class="fas fa-peso-sign"></i>
            </div>
          </div>
          <div class="stat-value">₱${todayRevenue.toFixed(2)}</div>
          <div class="stat-description">${todaySales.length} transactions</div>
        </div>
        <div class="stat-card">
          <div class="stat-header">
            <h3>Active Repairs</h3>
            <div class="stat-icon issued">
              <i class="fas fa-tools"></i>
            </div>
          </div>
          <div class="stat-value">${pendingRepairs}</div>
          <div class="stat-description">In progress</div>
        </div>
      </div>
    `
    salesSection.querySelector(".content-header").insertAdjacentHTML("afterend", statsHTML)
  }
}

// Add inventory management functions
async function fetchInventoryForCashier() {
  try {
    const res = await window.jobAPI.getProducts()
    renderInventoryForCashier(res.products || [])
    populateCategoryFilter(res.products || [])
  } catch (e) {
    showNotification("Failed to load inventory", "error")
  }
}

function renderInventoryForCashier(products) {
  const tbody = document.getElementById("inventoryTableBody")
  if (!tbody) return

  tbody.innerHTML = ""
  if (!products.length) {
    tbody.innerHTML = `<tr><td colspan='5' class='empty-state'>No products found</td></tr>`
    return
  }

  products.forEach((product) => {
    const stockStatus =
      product.stock === 0
        ? "Out of Stock"
        : product.stock <= (product.low_stock_threshold || 5)
          ? "Low Stock"
          : "In Stock"
    const statusClass =
      product.stock === 0
        ? "status-out-of-stock"
        : product.stock <= (product.low_stock_threshold || 5)
          ? "status-low-stock"
          : "status-in-stock"

    const tr = document.createElement("tr")
    tr.innerHTML = `
      <td>${product.name}</td>
      <td>${product.category}</td>
      <td>₱${product.price.toFixed(2)}</td>
      <td style="font-weight: bold; color: ${product.stock === 0 ? "#ef4444" : product.stock <= 5 ? "#f59e0b" : "#10b981"}">${product.stock}</td>
      <td><span class="status-badge ${statusClass}">${stockStatus}</span></td>
    `
    tbody.appendChild(tr)
  })
}

function populateCategoryFilter(products) {
  const categoryFilter = document.getElementById("categoryFilter")
  if (!categoryFilter) return

  const categories = [...new Set(products.map((p) => p.category))]
  categoryFilter.innerHTML =
    '<option value="">All Categories</option>' +
    categories.map((cat) => `<option value="${cat}">${cat}</option>`).join("")
}

// Add search and filter functionality
document.getElementById("inventorySearch")?.addEventListener("input", filterInventory)
document.getElementById("categoryFilter")?.addEventListener("change", filterInventory)

function filterInventory() {
  const searchTerm = document.getElementById("inventorySearch")?.value.toLowerCase() || ""
  const categoryFilter = document.getElementById("categoryFilter")?.value || ""
  const rows = document.querySelectorAll("#inventoryTableBody tr")

  rows.forEach((row) => {
    if (row.cells.length < 5) return // Skip empty state row

    const name = row.cells[0].textContent.toLowerCase()
    const category = row.cells[1].textContent

    const matchesSearch = name.includes(searchTerm)
    const matchesCategory = !categoryFilter || category === categoryFilter

    row.style.display = matchesSearch && matchesCategory ? "" : "none"
  })
}

document.addEventListener("DOMContentLoaded", async () => {
  await fetchSession()
  const session = await window.jobAPI.getCurrentSession()
  if (session) {
    document.getElementById("currentUserName").textContent = session.name
    document.getElementById("currentUserRole").textContent = session.role
    if (session.role !== "Cashier") {
      alert("Access denied. You don't have permission to access this page.")
      window.jobAPI.navigation.goToPage("./index.html")
      return
    }
  } else {
    window.jobAPI.navigation.goToPage("./index.html")
    return
  }
  setupNavigationEvents()
  showSection("sales")
  await fetchProductsForSales()
  fetchSales()
  fetchRepairs()
  fetchCashierCommissions()
  cart = []
  updateCartTable()
  await fetchCashierDashboardStats()
})

function setupNavigationEvents() {
  const navButtons = {
    salesNavBtn: "sales",
    inventoryNavBtn: "inventory",
    repairNavBtn: "repair",
    commissionNavBtn: "commission",
  }
  Object.entries(navButtons).forEach(([buttonId, section]) => {
    const button = document.getElementById(buttonId)
    if (button) {
      button.onclick = () => {
        showSection(section)
        setActiveNavBtn(button)
      }
    }
  })
  const logoutBtn = document.getElementById("logoutBtn")
  if (logoutBtn) logoutBtn.onclick = logout
}

function setActiveNavBtn(activeBtn) {
  document.querySelectorAll(".nav-button").forEach((btn) => btn.classList.remove("active"))
  activeBtn.classList.add("active")
}

function showSection(sectionName) {
  document.querySelectorAll(".content-section").forEach((section) => section.classList.add("hidden"))
  const targetSection = document.getElementById(`${sectionName}Section`)
  if (targetSection) targetSection.classList.remove("hidden")
  if (sectionName === "commission") fetchCashierCommissions()
  if (sectionName === "inventory") fetchInventoryForCashier()
  if (sectionName === "sales") fetchCashierDashboardStats()
}

function logout() {
  if (confirm("Are you sure you want to logout?")) {
    setTimeout(() => {
      window.jobAPI.logout()
      window.jobAPI.navigation.goToPage("./index.html")
    }, 500)
  }
}

// Declare showNotification and formatDateTime functions
showNotification = (message, type) => {
  // Implementation for showNotification
  console.log(`Notification: ${message} (${type})`)
}

formatDateTime = (date) => {
  // Implementation for formatDateTime
  return new Date(date).toLocaleString()
}
// Add further logic for sales, inventory, and repairs as needed.
