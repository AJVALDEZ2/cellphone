// Sidebar navigation logic for Cellphone Repair Shop
// Only show/hide navigation based on user role (Admin or Cashier)

function applySidebarByRole(currentUserRole) {
  // Hide/show nav items based on role
  const adminNavIds = [
    "dashboardNavBtn",
    "productsNavBtn",
    "salesNavBtn",
    "repairsNavBtn",
    "commissionsNavBtn",
    "usersNavBtn",
    "reportsNavBtn"
  ];
  const cashierNavIds = [
    "salesNavBtn",
    "inventoryNavBtn",
    "repairNavBtn"
  ];
  // Hide all navs first
  document.querySelectorAll(".nav-item").forEach(item => item.style.display = "none");
  if (currentUserRole === "Admin") {
    adminNavIds.forEach(id => {
      const btn = document.getElementById(id);
      if (btn) btn.parentElement.style.display = "block";
    });
  } else if (currentUserRole === "Cashier") {
    cashierNavIds.forEach(id => {
      const btn = document.getElementById(id);
      if (btn) btn.parentElement.style.display = "block";
    });
  }
}

// For browser usage
window.applySidebarByRole = applySidebarByRole;
