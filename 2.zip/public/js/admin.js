// Admin dashboard functionality for Cellphone Repair Shop
let currentUserRole = null
let currentReportData = null
let currentSession = null // Declare currentSession variable

// Declare showNotification and formatDateTime functions
function showNotification(message, type) {
  // Implementation for showing notifications
  console.log(`Notification (${type}): ${message}`)
}

function formatDateTime(date) {
  // Implementation for formatting date
  return new Date(date).toLocaleString()
}

async function fetchSession() {
  const session = await window.jobAPI.getCurrentSession()
  currentUserRole = session?.role || null
  currentSession = session // Assign session to currentSession variable
}

// --- PRODUCTS MANAGEMENT ---
async function fetchProducts() {
  try {
    const res = await window.jobAPI.getProducts()
    renderProducts(res.products || [])
  } catch (e) {
    showNotification("Failed to load products", "error")
  }
}

function renderProducts(products) {
  const tbody = document.getElementById("productsTableBody")
  tbody.innerHTML = ""
  if (!products.length) {
    tbody.innerHTML = `<tr><td colspan='5' class='empty-state'>No products found</td></tr>`
    return
  }
  products.forEach((product) => {
    const tr = document.createElement("tr")
    tr.innerHTML = `
      <td>${product.name}</td>
      <td>${product.category}</td>
      <td>${product.price.toFixed(2)}</td>
      <td>${product.stock}</td>
      <td>
        <button class='btn-secondary btn-sm' onclick='editProduct(${product.id})'><i class='fas fa-edit'></i></button>
        <button class='btn-danger btn-sm' onclick='deleteProduct(${product.id})'><i class='fas fa-trash'></i></button>
      </td>
    `
    tbody.appendChild(tr)
  })
}

function showProductModal(edit = false, product = {}) {
  document.getElementById("productModalTitle").textContent = edit ? "Edit Product" : "Add Product"
  document.getElementById("productId").value = product.id || ""
  document.getElementById("productName").value = product.name || ""
  document.getElementById("productCategory").value = product.category || ""
  document.getElementById("productPrice").value = product.price || ""
  document.getElementById("productStock").value = product.stock || ""
  document.getElementById("productModal").classList.remove("hidden")
}

function hideProductModal() {
  document.getElementById("productModal").classList.add("hidden")
}

// Event handlers
window.editProduct = async (id) => {
  try {
    const res = await window.jobAPI.getProductById(id)
    if (res.success) {
      showProductModal(true, res.product)
    } else {
      showNotification(res.message || "Product not found", "error")
    }
  } catch (e) {
    showNotification("Failed to load product", "error")
  }
}

window.deleteProduct = async (id) => {
  if (!confirm("Delete this product?")) return
  try {
    const res = await window.jobAPI.deleteProduct(id)
    if (res.success) {
      showNotification("Product deleted", "success")
      fetchProducts()
    } else {
      showNotification(res.message || "Delete failed", "error")
    }
  } catch (e) {
    showNotification("Delete failed", "error")
  }
}

// Add after existing product functions
async function fetchLowStockProducts() {
  try {
    const res = await window.jobAPI.getLowStockProducts()
    renderLowStockProducts(res.products || [])
  } catch (e) {
    showNotification("Failed to load low stock products", "error")
  }
}

function renderLowStockProducts(products) {
  const tbody = document.getElementById("lowStockTableBody")
  if (!tbody) return

  tbody.innerHTML = ""
  if (!products.length) {
    tbody.innerHTML = `<tr><td colspan='4' class='empty-state'>No low stock items</td></tr>`
    return
  }

  products.forEach((product) => {
    const tr = document.createElement("tr")
    tr.innerHTML = `
      <td>${product.name}</td>
      <td style="color: ${product.stock === 0 ? "#ef4444" : "#f59e0b"}; font-weight: bold;">${product.stock}</td>
      <td>${product.low_stock_threshold || 5}</td>
      <td>
        <button class='btn-warning btn-sm' onclick='showStockAdjustmentModal(${product.id}, "${product.name}")'>
          <i class='fas fa-plus'></i> Restock
        </button>
      </td>
    `
    tbody.appendChild(tr)
  })
}

window.showStockAdjustmentModal = (productId, productName) => {
  document.getElementById("adjustmentProductId").value = productId
  document.getElementById("adjustmentProductName").value = productName
  document.getElementById("adjustmentType").value = "add"
  document.getElementById("adjustmentQuantity").value = ""
  document.getElementById("adjustmentReason").value = ""
  document.getElementById("stockAdjustmentModal").classList.remove("hidden")
}

// Add event handlers for stock adjustment modal
document.getElementById("closeStockAdjustmentModal").onclick = () => {
  document.getElementById("stockAdjustmentModal").classList.add("hidden")
}

document.getElementById("cancelStockAdjustmentBtn").onclick = () => {
  document.getElementById("stockAdjustmentModal").classList.add("hidden")
}

document.getElementById("stockAdjustmentForm").onsubmit = async (e) => {
  e.preventDefault()
  const formData = new FormData(e.target)
  const adjustmentData = {
    product_id: Number.parseInt(formData.get("product_id")),
    adjustment_type: formData.get("adjustment_type"),
    quantity: Number.parseInt(formData.get("quantity")),
    reason: formData.get("reason"),
    user_id: currentSession?.userId || 1,
  }

  try {
    const res = await window.jobAPI.adjustProductStock(adjustmentData)
    if (res.success) {
      showNotification("Stock adjusted successfully", "success")
      document.getElementById("stockAdjustmentModal").classList.add("hidden")
      fetchProducts()
      fetchLowStockProducts()
    } else {
      showNotification(res.message || "Failed to adjust stock", "error")
    }
  } catch (e) {
    showNotification("Failed to adjust stock", "error")
  }
}

// --- SALES MODULE ---
let cart = []
let productsList = []

async function fetchProductsForSales() {
  try {
    const res = await window.jobAPI.getProducts()
    productsList = res.products || []
    const select = document.getElementById("productSelect")
    select.innerHTML = productsList
      .map(
        (p) =>
          `<option value="${p.id}" data-price="${p.price}">${p.name} (${p.category}) - ₱${p.price.toFixed(2)}</option>`,
      )
      .join("")
  } catch (e) {
    showNotification("Failed to load products", "error")
  }
}

function updateCartTable() {
  const tbody = document.getElementById("cartTableBody")
  tbody.innerHTML = ""
  let total = 0
  cart.forEach((item, idx) => {
    const tr = document.createElement("tr")
    tr.innerHTML = `
      <td>${item.name}</td>
      <td>${item.quantity}</td>
      <td>₱${item.unit_price.toFixed(2)}</td>
      <td>₱${item.total_price.toFixed(2)}</td>
      <td><button class='btn-danger btn-sm' onclick='removeCartItem(${idx})'><i class='fas fa-trash'></i></button></td>
    `
    tbody.appendChild(tr)
    total += item.total_price
  })
  document.getElementById("salesTotal").textContent = total.toFixed(2)
}

window.removeCartItem = (idx) => {
  cart.splice(idx, 1)
  updateCartTable()
}

document.getElementById("addToCartBtn").onclick = () => {
  const productId = Number.parseInt(document.getElementById("productSelect").value)
  const qty = Number.parseInt(document.getElementById("productQty").value)
  if (!productId || isNaN(qty) || qty < 1) {
    showNotification("Select a product and enter a valid quantity", "error")
    return
  }
  const product = productsList.find((p) => p.id === productId)
  if (!product) {
    showNotification("Product not found", "error")
    return
  }
  // Check if already in cart
  const existing = cart.find((item) => item.product_id === productId)
  if (existing) {
    existing.quantity += qty
    existing.total_price = existing.quantity * existing.unit_price
  } else {
    cart.push({
      product_id: product.id,
      name: product.name,
      quantity: qty,
      unit_price: product.price,
      total_price: qty * product.price,
    })
  }
  updateCartTable()
}

document.getElementById("salesForm").onsubmit = async (e) => {
  e.preventDefault()
  if (cart.length === 0) {
    showNotification("Cart is empty", "error")
    return
  }
  const client_name = document.getElementById("clientName").value.trim()
  const payment_method = document.getElementById("paymentMethod").value
  const total_amount = Number.parseFloat(document.getElementById("salesTotal").textContent)
  try {
    const res = await window.jobAPI.createSale({
      cashier_id: window.currentUserId, // Set this from session if available
      client_name,
      total_amount,
      payment_method,
      items: cart.map((item) => ({
        product_id: item.product_id,
        quantity: item.quantity,
        unit_price: item.unit_price,
        total_price: item.total_price,
      })),
    })
    if (res.success) {
      showNotification("Sale recorded", "success")
      cart = []
      updateCartTable()
      fetchSales()
      document.getElementById("salesForm").reset()
    } else {
      showNotification(res.message || "Failed to record sale", "error")
    }
  } catch (e) {
    showNotification("Failed to record sale", "error")
  }
}

// --- SALES LISTING ---
async function fetchSales() {
  try {
    const res = await window.jobAPI.getSales()
    renderSales(res.sales || [])
  } catch (e) {
    showNotification("Failed to load sales", "error")
  }
}

function renderSales(sales) {
  const tbody = document.getElementById("salesTableBody")
  tbody.innerHTML = ""
  if (!sales.length) {
    tbody.innerHTML = `<tr><td colspan='5' class='empty-state'>No sales found</td></tr>`
    return
  }
  sales.forEach((sale) => {
    const tr = document.createElement("tr")
    tr.innerHTML = `
      <td>${formatDateTime(sale.date)}</td>
      <td>${sale.client_name || "-"}</td>
      <td>₱${sale.total_amount.toFixed(2)}</td>
      <td>${sale.payment_method}</td>
      <td><button class='btn-info btn-sm' onclick='viewSaleDetails(${sale.id})'><i class='fas fa-eye'></i></button></td>
    `
    tbody.appendChild(tr)
  })
}

window.viewSaleDetails = async (id) => {
  try {
    const res = await window.jobAPI.getSaleById(id)
    if (res.success) {
      showSaleDetailsModal(res.sale)
    } else {
      showNotification(res.message || "Sale not found", "error")
    }
  } catch (e) {
    showNotification("Failed to load sale details", "error")
  }
}

function showSaleDetailsModal(sale) {
  const modal = document.getElementById("saleDetailsModal")
  const body = document.getElementById("saleDetailsBody")
  body.innerHTML = `
    <div><strong>Date:</strong> ${formatDateTime(sale.date)}</div>
    <div><strong>Client:</strong> ${sale.client_name || "-"}</div>
    <div><strong>Total:</strong> ₱${sale.total_amount.toFixed(2)}</div>
    <div><strong>Payment:</strong> ${sale.payment_method}</div>
    <div><strong>Items:</strong></div>
    <table class='table'><thead><tr><th>Product</th><th>Qty</th><th>Unit Price</th><th>Total</th></tr></thead><tbody>
      ${sale.items
        .map(
          (item) => `
        <tr>
          <td>${item.product_name}</td>
          <td>${item.quantity}</td>
          <td>₱${item.unit_price.toFixed(2)}</td>
          <td>₱${item.total_price.toFixed(2)}</td>
        </tr>
      `,
        )
        .join("")}
    </tbody></table>
  `
  modal.classList.remove("hidden")
}

document.getElementById("closeSaleDetailsModal").onclick = () => {
  document.getElementById("saleDetailsModal").classList.add("hidden")
}

// --- REPAIRS MODULE ---
async function fetchRepairs() {
  try {
    const res = await window.jobAPI.getRepairs()
    renderRepairs(res.repairs || [])
  } catch (e) {
    showNotification("Failed to load repairs", "error")
  }
}

function renderRepairs(repairs) {
  const tbody = document.getElementById("repairsTableBody")
  tbody.innerHTML = ""
  if (!repairs.length) {
    tbody.innerHTML = `<tr><td colspan='7' class='empty-state'>No repairs found</td></tr>`
    return
  }
  repairs.forEach((repair) => {
    const tr = document.createElement("tr")
    tr.innerHTML = `
      <td>${formatDateTime(repair.date)}</td>
      <td>${repair.client_name}</td>
      <td>${repair.device_model}</td>
      <td><span class="status-badge status-${repair.status.toLowerCase().replace(" ", "-")}">${repair.status}</span></td>
      <td>₱${repair.service_fee.toFixed(2)}</td>
      <td>₱${repair.commission_amount.toFixed(2)}</td>
      <td>
        <button class='btn-secondary btn-sm' onclick='editRepair(${repair.id})'><i class='fas fa-edit'></i></button>
        <button class='btn-info btn-sm' onclick='viewRepairDetails(${repair.id})'><i class='fas fa-eye'></i></button>
      </td>
    `
    tbody.appendChild(tr)
  })
}

function showRepairModal(edit = false, repair = {}) {
  document.getElementById("repairModalTitle").textContent = edit ? "Edit Repair" : "Add Repair"
  document.getElementById("repairId").value = repair.id || ""
  document.getElementById("repairDeviceModel").value = repair.device_model || ""
  document.getElementById("repairClientName").value = repair.client_name || ""
  document.getElementById("repairClientPhone").value = repair.client_phone || ""
  document.getElementById("repairIssueDescription").value = repair.issue_description || ""
  document.getElementById("repairPartsUsed").value = repair.parts_used || ""
  document.getElementById("repairServiceFee").value = repair.service_fee || ""
  document.getElementById("repairCommissionAmount").value = repair.commission_amount || ""
  document.getElementById("repairStatus").value = repair.status || "Pending"
  document.getElementById("repairModal").classList.remove("hidden")
}

function hideRepairModal() {
  document.getElementById("repairModal").classList.add("hidden")
}

window.editRepair = async (id) => {
  try {
    const res = await window.jobAPI.getRepairById(id)
    if (res.success) {
      showRepairModal(true, res.repair)
    } else {
      showNotification(res.message || "Repair not found", "error")
    }
  } catch (e) {
    showNotification("Failed to load repair", "error")
  }
}

window.viewRepairDetails = async (id) => {
  try {
    const res = await window.jobAPI.getRepairById(id)
    if (res.success) {
      showRepairDetailsModal(res.repair)
    } else {
      showNotification(res.message || "Repair not found", "error")
    }
  } catch (e) {
    showNotification("Failed to load repair details", "error")
  }
}

function showRepairDetailsModal(repair) {
  const modal = document.getElementById("repairDetailsModal")
  const body = document.getElementById("repairDetailsBody")
  body.innerHTML = `
    <div><strong>Date:</strong> ${formatDateTime(repair.date)}</div>
    <div><strong>Client:</strong> ${repair.client_name}</div>
    <div><strong>Phone:</strong> ${repair.client_phone}</div>
    <div><strong>Device:</strong> ${repair.device_model}</div>
    <div><strong>Issue:</strong> ${repair.issue_description}</div>
    <div><strong>Parts Used:</strong> ${repair.parts_used || "-"}</div>
    <div><strong>Service Fee:</strong> ₱${repair.service_fee.toFixed(2)}</div>
    <div><strong>Commission:</strong> ₱${repair.commission_amount.toFixed(2)}</div>
    <div><strong>Status:</strong> <span class="status-badge status-${repair.status.toLowerCase().replace(" ", "-")}">${repair.status}</span></div>
  `
  modal.classList.remove("hidden")
}

document.getElementById("closeRepairDetailsModal").onclick = () => {
  document.getElementById("repairDetailsModal").classList.add("hidden")
}

// --- COMMISSIONS MODULE ---
async function fetchCommissions() {
  try {
    const res = await window.jobAPI.getCommissions()
    renderCommissions(res.commissions || [])
    updateCommissionStats(res.commissions || [])
  } catch (e) {
    showNotification("Failed to load commissions", "error")
  }
}

function renderCommissions(commissions) {
  const tbody = document.getElementById("commissionsTableBody")
  tbody.innerHTML = ""
  if (!commissions.length) {
    tbody.innerHTML = `<tr><td colspan='8' class='empty-state'>No commissions found</td></tr>`
    return
  }
  commissions.forEach((commission) => {
    const tr = document.createElement("tr")
    tr.innerHTML = `
      <td>${formatDateTime(commission.date)}</td>
      <td>${commission.cashier_name}</td>
      <td>${commission.repair_job}</td>
      <td>${commission.client_name}</td>
      <td>₱${commission.commission_amount.toFixed(2)}</td>
      <td><span class="status-badge status-${commission.status.toLowerCase()}">${commission.status}</span></td>
      <td>${commission.payment_date ? formatDateTime(commission.payment_date) : "-"}</td>
      <td>
        ${
          commission.status === "Unpaid"
            ? `<button class='btn-success btn-sm' onclick='recordCommissionPayment(${commission.id})'><i class='fas fa-money-bill'></i> Pay</button>`
            : `<button class='btn-info btn-sm' onclick='viewCommissionDetails(${commission.id})'><i class='fas fa-eye'></i></button>`
        }
      </td>
    `
    tbody.appendChild(tr)
  })
}

function updateCommissionStats(commissions) {
  const total = commissions.reduce((sum, c) => sum + Number.parseFloat(c.commission_amount), 0)
  const pending = commissions
    .filter((c) => c.status === "Unpaid")
    .reduce((sum, c) => sum + Number.parseFloat(c.commission_amount), 0)

  const now = new Date()
  const thisMonth = commissions
    .filter((c) => {
      const commissionDate = new Date(c.date)
      return commissionDate.getMonth() === now.getMonth() && commissionDate.getFullYear() === now.getFullYear()
    })
    .reduce((sum, c) => sum + Number.parseFloat(c.commission_amount), 0)

  document.getElementById("totalCommissions").textContent = `₱${total.toFixed(2)}`
  document.getElementById("pendingCommissions").textContent = `₱${pending.toFixed(2)}`
  document.getElementById("monthlyCommissions").textContent = `₱${thisMonth.toFixed(2)}`
}

window.recordCommissionPayment = async (id) => {
  try {
    const res = await window.jobAPI.getCommissionById(id)
    if (res.success) {
      showCommissionPaymentModal(res.commission)
    } else {
      showNotification(res.message || "Commission not found", "error")
    }
  } catch (e) {
    showNotification("Failed to load commission", "error")
  }
}

window.viewCommissionDetails = async (id) => {
  try {
    const res = await window.jobAPI.getCommissionById(id)
    if (res.success) {
      showCommissionDetailsModal(res.commission)
    } else {
      showNotification(res.message || "Commission not found", "error")
    }
  } catch (e) {
    showNotification("Failed to load commission details", "error")
  }
}

function showCommissionPaymentModal(commission) {
  document.getElementById("commissionId").value = commission.id
  document.getElementById("commissionCashierName").value = commission.cashier_name
  document.getElementById("commissionRepairJob").value = commission.repair_job
  document.getElementById("commissionAmount").value = `₱${commission.commission_amount.toFixed(2)}`
  document.getElementById("commissionPaymentDate").value = new Date().toISOString().split("T")[0]
  document.getElementById("commissionPaymentModal").classList.remove("hidden")
}

function showCommissionDetailsModal(commission) {
  const modal = document.getElementById("commissionPaymentModal")
  const body = document.getElementById("commissionPaymentForm")
  body.innerHTML = `
    <div><strong>Date:</strong> ${formatDateTime(commission.date)}</div>
    <div><strong>Cashier:</strong> ${commission.cashier_name}</div>
    <div><strong>Repair Job:</strong> ${commission.repair_job}</div>
    <div><strong>Client:</strong> ${commission.client_name}</div>
    <div><strong>Commission Amount:</strong> ₱${commission.commission_amount.toFixed(2)}</div>
    <div><strong>Status:</strong> <span class="status-badge status-${commission.status.toLowerCase()}">${commission.status}</span></div>
    <div><strong>Payment Date:</strong> ${commission.payment_date ? formatDateTime(commission.payment_date) : "-"}</div>
    <div><strong>Payment Method:</strong> ${commission.payment_method || "-"}</div>
    <div><strong>Notes:</strong> ${commission.notes || "-"}</div>
  `
  modal.classList.remove("hidden")
}

document.getElementById("closeCommissionPaymentModal").onclick = () => {
  document.getElementById("commissionPaymentModal").classList.add("hidden")
}

document.getElementById("cancelCommissionPaymentBtn").onclick = () => {
  document.getElementById("commissionPaymentModal").classList.add("hidden")
}

document.getElementById("commissionPaymentForm").onsubmit = async (e) => {
  e.preventDefault()
  const formData = new FormData(e.target)
  const paymentData = {
    id: document.getElementById("commissionId").value,
    payment_date: formData.get("paymentDate"),
    payment_method: formData.get("paymentMethod"),
    notes: formData.get("notes"),
  }
  try {
    const res = await window.jobAPI.updateCommissionPayment(paymentData)
    if (res.success) {
      showNotification("Commission payment recorded", "success")
      document.getElementById("commissionPaymentModal").classList.add("hidden")
      fetchCommissions()
    } else {
      showNotification(res.message || "Failed to record payment", "error")
    }
  } catch (e) {
    showNotification("Failed to record payment", "error")
  }
}

// --- REPORTS MODULE ---

// Initialize report filters
async function initializeReportFilters() {
  try {
    // Load cashiers for filter dropdowns
    const cashiers = await window.jobAPI.getCashiers()
    const cashierOptions = cashiers.map((c) => `<option value="${c.id}">${c.name}</option>`).join("")

    document.getElementById("salesReportCashier").innerHTML = '<option value="">All Cashiers</option>' + cashierOptions

    // Load product categories for inventory reports
    const products = await window.jobAPI.getProducts()
    const categories = [...new Set(products.map((p) => p.category))]
    const categoryOptions = categories.map((c) => `<option value="${c}">${c}</option>`).join("")

    document.getElementById("inventoryReportCategory").innerHTML =
      '<option value="">All Categories</option>' + categoryOptions
  } catch (e) {
    console.error("Failed to initialize report filters:", e)
  }
}

// Sales Report Generation
window.generateSalesReport = async () => {
  try {
    const filters = {
      dateFrom: document.getElementById("salesReportDateFrom").value,
      dateTo: document.getElementById("salesReportDateTo").value,
      cashierId: document.getElementById("salesReportCashier").value,
    }

    const res = await window.jobAPI.generateSalesReport(filters)
    if (res.success) {
      currentReportData = res.report
      showReportPreview("Sales Report", res.report)
    } else {
      showNotification(res.message || "Failed to generate sales report", "error")
    }
  } catch (e) {
    showNotification("Failed to generate sales report", "error")
  }
}

// Repair Report Generation
window.generateRepairReport = async () => {
  try {
    const filters = {
      dateFrom: document.getElementById("repairReportDateFrom").value,
      dateTo: document.getElementById("repairReportDateTo").value,
      status: document.getElementById("repairReportStatus").value,
    }

    const res = await window.jobAPI.generateRepairReport(filters)
    if (res.success) {
      currentReportData = res.report
      showReportPreview("Repair Report", res.report)
    } else {
      showNotification(res.message || "Failed to generate repair report", "error")
    }
  } catch (e) {
    showNotification("Failed to generate repair report", "error")
  }
}

// Commission Report Generation
window.generateCommissionReport = async () => {
  try {
    const filters = {
      dateFrom: document.getElementById("commissionReportDateFrom").value,
      dateTo: document.getElementById("commissionReportDateTo").value,
      status: document.getElementById("commissionReportStatus").value,
    }

    const res = await window.jobAPI.generateCommissionReport(filters)
    if (res.success) {
      currentReportData = res.report
      showReportPreview("Commission Report", res.report)
    } else {
      showNotification(res.message || "Failed to generate commission report", "error")
    }
  } catch (e) {
    showNotification("Failed to generate commission report", "error")
  }
}

// Inventory Report Generation
window.generateInventoryReport = async () => {
  try {
    const filters = {
      type: document.getElementById("inventoryReportType").value,
      category: document.getElementById("inventoryReportCategory").value,
    }

    const res = await window.jobAPI.generateInventoryReport(filters)
    if (res.success) {
      currentReportData = res.report
      showReportPreview("Inventory Report", res.report)
    } else {
      showNotification(res.message || "Failed to generate inventory report", "error")
    }
  } catch (e) {
    showNotification("Failed to generate inventory report", "error")
  }
}

// Show Report Preview
function showReportPreview(title, reportData) {
  const previewSection = document.getElementById("reportPreviewSection")
  const content = document.getElementById("reportPreviewContent")

  let html = `<h3>${title}</h3>`
  html += `<p><strong>Generated:</strong> ${new Date().toLocaleString()}</p>`

  if (reportData.summary) {
    html += `<div class="report-summary">`
    Object.entries(reportData.summary).forEach(([key, value]) => {
      html += `<div><strong>${key}:</strong> ${value}</div>`
    })
    html += `</div>`
  }

  if (reportData.data && reportData.data.length > 0) {
    html += `<div class="table-container">`
    html += `<table class="table">`
    html += `<thead><tr>`

    // Generate headers from first data row
    Object.keys(reportData.data[0]).forEach((key) => {
      html += `<th>${key.replace(/_/g, " ").toUpperCase()}</th>`
    })
    html += `</tr></thead><tbody>`

    // Generate data rows
    reportData.data.forEach((row) => {
      html += `<tr>`
      Object.values(row).forEach((value) => {
        html += `<td>${value}</td>`
      })
      html += `</tr>`
    })

    html += `</tbody></table>`
    html += `</div>`
  } else {
    html += `<p>No data found for the selected criteria.</p>`
  }

  content.innerHTML = html
  previewSection.classList.remove("hidden")
}

// Export Report to CSV
window.exportReportToCSV = () => {
  if (!currentReportData || !currentReportData.data) {
    showNotification("No report data to export", "error")
    return
  }

  try {
    const csvContent = convertToCSV(currentReportData.data)
    const blob = new Blob([csvContent], { type: "text/csv" })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `report_${new Date().toISOString().split("T")[0]}.csv`
    a.click()
    window.URL.revokeObjectURL(url)
    showNotification("Report exported successfully", "success")
  } catch (e) {
    showNotification("Failed to export report", "error")
  }
}

// Print Report
window.printReport = () => {
  const printContent = document.getElementById("reportPreviewContent").innerHTML
  const printWindow = window.open("", "_blank")
  printWindow.document.write(`
    <html>
      <head>
        <title>Report</title>
        <style>
          body { font-family: Arial, sans-serif; margin: 20px; }
          table { border-collapse: collapse; width: 100%; }
          th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
          th { background-color: #f2f2f2; }
          .report-summary { margin: 20px 0; padding: 10px; background: #f9f9f9; }
        </style>
      </head>
      <body>${printContent}</body>
    </html>
  `)
  printWindow.document.close()
  printWindow.print()
}

// Close Report Preview
window.closeReportPreview = () => {
  document.getElementById("reportPreviewSection").classList.add("hidden")
  currentReportData = null
}

// Convert data to CSV format
function convertToCSV(data) {
  if (!data || data.length === 0) return ""

  const headers = Object.keys(data[0])
  const csvRows = [headers.join(",")]

  data.forEach((row) => {
    const values = headers.map((header) => {
      const value = row[header]
      return `"${value}"`
    })
    csvRows.push(values.join(","))
  })

  return csvRows.join("\n")
}

// --- USER MANAGEMENT MODULE ---
async function fetchUsers() {
  try {
    const res = await window.jobAPI.getUsers()
    renderUsers(res.users || [])
  } catch (e) {
    showNotification("Failed to load users", "error")
  }
}

function renderUsers(users) {
  const tbody = document.getElementById("usersTableBody")
  tbody.innerHTML = ""
  if (!users.length) {
    tbody.innerHTML = `<tr><td colspan='7' class='empty-state'>No users found</td></tr>`
    return
  }
  users.forEach((user) => {
    const tr = document.createElement("tr")
    tr.innerHTML = `
      <td>${user.name}</td>
      <td>${user.username}</td>
      <td><span class="role-badge role-${user.role.toLowerCase()}">${user.role}</span></td>
      <td>${user.email}</td>
      <td><span class="status-badge status-${user.status.toLowerCase()}">${user.status}</span></td>
      <td>${user.last_login ? formatDateTime(user.last_login) : "Never"}</td>
      <td>
        <button class='btn-info btn-sm' onclick='viewUserDetails(${user.id})'><i class='fas fa-eye'></i></button>
        <button class='btn-warning btn-sm' onclick='editUser(${user.id})'><i class='fas fa-edit'></i></button>
        ${user.id !== 1 ? `<button class='btn-danger btn-sm' onclick='deleteUser(${user.id})'><i class='fas fa-trash'></i></button>` : ""}
      </td>
    `
    tbody.appendChild(tr)
  })
}

window.addUser = () => {
  document.getElementById("userModalTitle").textContent = "Add User"
  document.getElementById("userForm").reset()
  document.getElementById("userId").value = ""
  document.getElementById("userPassword").required = true
  document.getElementById("userConfirmPassword").required = true
  document.getElementById("userModal").classList.remove("hidden")
}

window.editUser = async (id) => {
  try {
    const res = await window.jobAPI.getUserById(id)
    if (res.success) {
      showUserModal(res.user, true)
    } else {
      showNotification(res.message || "User not found", "error")
    }
  } catch (e) {
    showNotification("Failed to load user", "error")
  }
}

window.viewUserDetails = async (id) => {
  try {
    const res = await window.jobAPI.getUserById(id)
    if (res.success) {
      showUserDetailsModal(res.user)
    } else {
      showNotification(res.message || "User not found", "error")
    }
  } catch (e) {
    showNotification("Failed to load user details", "error")
  }
}

window.deleteUser = async (id) => {
  if (!confirm("Are you sure you want to delete this user? This action cannot be undone.")) {
    return
  }
  try {
    const res = await window.jobAPI.deleteUser(id)
    if (res.success) {
      showNotification("User deleted successfully", "success")
      fetchUsers()
    } else {
      showNotification(res.message || "Failed to delete user", "error")
    }
  } catch (e) {
    showNotification("Failed to delete user", "error")
  }
}

function showUserModal(user = null, isEdit = false) {
  document.getElementById("userModalTitle").textContent = isEdit ? "Edit User" : "Add User"
  document.getElementById("userId").value = user ? user.id : ""
  document.getElementById("userName").value = user ? user.name : ""
  document.getElementById("userUsername").value = user ? user.username : ""
  document.getElementById("userEmail").value = user ? user.email : ""
  document.getElementById("userRole").value = user ? user.role : ""
  document.getElementById("userStatus").value = user ? user.status : "Active"

  // Password fields are optional when editing
  document.getElementById("userPassword").required = !isEdit
  document.getElementById("userConfirmPassword").required = !isEdit

  document.getElementById("userModal").classList.remove("hidden")
}

function showUserDetailsModal(user) {
  const body = document.getElementById("userDetailsBody")
  body.innerHTML = `
    <div class="user-details">
      <div><strong>Name:</strong> ${user.name}</div>
      <div><strong>Username:</strong> ${user.username}</div>
      <div><strong>Email:</strong> ${user.email}</div>
      <div><strong>Role:</strong> <span class="role-badge role-${user.role.toLowerCase()}">${user.role}</span></div>
      <div><strong>Status:</strong> <span class="status-badge status-${user.status.toLowerCase()}">${user.status}</span></div>
      <div><strong>Created:</strong> ${formatDateTime(user.created_at)}</div>
      <div><strong>Last Login:</strong> ${user.last_login ? formatDateTime(user.last_login) : "Never"}</div>
      <div><strong>Last Updated:</strong> ${formatDateTime(user.updated_at)}</div>
    </div>
  `
  document.getElementById("userDetailsModal").classList.remove("hidden")
}

// User Modal Event Handlers
document.getElementById("addUserBtn").onclick = window.addUser

document.getElementById("closeUserModal").onclick = () => {
  document.getElementById("userModal").classList.add("hidden")
}

document.getElementById("cancelUserBtn").onclick = () => {
  document.getElementById("userModal").classList.add("hidden")
}

document.getElementById("closeUserDetailsModal").onclick = () => {
  document.getElementById("userDetailsModal").classList.add("hidden")
}

document.getElementById("userForm").onsubmit = async (e) => {
  e.preventDefault()
  const formData = new FormData(e.target)
  const password = formData.get("password")
  const confirmPassword = formData.get("confirmPassword")

  // Validate password confirmation
  if (password && password !== confirmPassword) {
    showNotification("Passwords do not match", "error")
    return
  }

  const userData = {
    name: formData.get("name"),
    username: formData.get("username"),
    email: formData.get("email"),
    role: formData.get("role"),
    status: formData.get("status"),
  }

  // Only include password if provided
  if (password) {
    userData.password = password
  }

  const userId = document.getElementById("userId").value
  const isEdit = !!userId

  try {
    let res
    if (isEdit) {
      userData.id = userId
      res = await window.jobAPI.updateUser(userData)
    } else {
      res = await window.jobAPI.createUser(userData)
    }

    if (res.success) {
      showNotification(`User ${isEdit ? "updated" : "created"} successfully`, "success")
      document.getElementById("userModal").classList.add("hidden")
      fetchUsers()
    } else {
      showNotification(res.message || `Failed to ${isEdit ? "update" : "create"} user`, "error")
    }
  } catch (e) {
    showNotification(`Failed to ${isEdit ? "update" : "create"} user`, "error")
  }
}

// --- INIT ---
document.addEventListener("DOMContentLoaded", async () => {
  await fetchSession()
  const session = await window.jobAPI.getCurrentSession()
  if (session) {
    document.getElementById("currentUserName").textContent = session.name
    document.getElementById("currentUserRole").textContent = session.role
    if (session.role !== "Admin") {
      alert("Access denied. You don't have permission to access this page.")
      window.jobAPI.navigation.goToPage("./index.html")
      return
    }
  } else {
    window.jobAPI.navigation.goToPage("./index.html")
    return
  }
  setupNavigationEvents()
  showSection("dashboard")
  // Products section events
  document.getElementById("addProductBtn").onclick = () => showProductModal(false)
  document.getElementById("closeProductModal").onclick = hideProductModal
  document.getElementById("cancelProductBtn").onclick = hideProductModal
  // Repairs section events
  document.getElementById("addRepairBtn").onclick = () => showRepairModal(false)
  document.getElementById("closeRepairModal").onclick = hideRepairModal
  document.getElementById("cancelRepairBtn").onclick = hideRepairModal
  document.getElementById("productForm").onsubmit = async (e) => {
    e.preventDefault()
    const id = document.getElementById("productId").value
    const name = document.getElementById("productName").value.trim()
    const category = document.getElementById("productCategory").value.trim()
    const price = Number.parseFloat(document.getElementById("productPrice").value)
    const stock = Number.parseInt(document.getElementById("productStock").value)
    if (!name || !category || isNaN(price) || isNaN(stock)) {
      showNotification("Please fill all fields", "error")
      return
    }
    try {
      let res
      if (id) {
        res = await window.jobAPI.updateProduct({ id, name, category, price, stock })
      } else {
        res = await window.jobAPI.createProduct({ name, category, price, stock })
      }
      if (res.success) {
        showNotification("Product saved", "success")
        hideProductModal()
        fetchProducts()
      } else {
        showNotification(res.message || "Save failed", "error")
      }
    } catch (e) {
      showNotification("Save failed", "error")
    }
  }
  // Repair form submission
  document.getElementById("repairForm").onsubmit = async (e) => {
    e.preventDefault()
    const id = document.getElementById("repairId").value
    const repairData = {
      device_model: document.getElementById("repairDeviceModel").value.trim(),
      client_name: document.getElementById("repairClientName").value.trim(),
      client_phone: document.getElementById("repairClientPhone").value.trim(),
      issue_description: document.getElementById("repairIssueDescription").value.trim(),
      parts_used: document.getElementById("repairPartsUsed").value.trim(),
      service_fee: Number.parseFloat(document.getElementById("repairServiceFee").value),
      commission_amount: Number.parseFloat(document.getElementById("repairCommissionAmount").value),
      status: document.getElementById("repairStatus").value,
    }
    if (
      !repairData.device_model ||
      !repairData.client_name ||
      !repairData.client_phone ||
      !repairData.issue_description ||
      isNaN(repairData.service_fee) ||
      isNaN(repairData.commission_amount)
    ) {
      showNotification("Please fill all required fields", "error")
      return
    }
    try {
      let res
      if (id) {
        res = await window.jobAPI.updateRepair({ id, ...repairData })
      } else {
        res = await window.jobAPI.createRepair(repairData)
      }
      if (res.success) {
        showNotification("Repair saved", "success")
        hideRepairModal()
        fetchRepairs()
      } else {
        showNotification(res.message || "Save failed", "error")
      }
    } catch (e) {
      showNotification("Save failed", "error")
    }
  }
  await fetchProductsForSales()
  fetchSales()
  fetchRepairs()
  fetchCommissions()
  fetchUsers()
  initializeReportFilters()
  cart = []
  updateCartTable()

  // Add dashboard statistics
  async function fetchDashboardStats() {
    try {
      const [products, sales, repairs, commissions] = await Promise.all([
        window.jobAPI.getProducts(),
        window.jobAPI.getSales(),
        window.jobAPI.getRepairs(),
        window.jobAPI.getCommissions(),
      ])

      updateDashboardStats({
        products: products.products || [],
        sales: sales.sales || [],
        repairs: repairs.repairs || [],
        commissions: commissions.commissions || [],
      })
    } catch (error) {
      console.error("Failed to fetch dashboard stats:", error)
    }
  }

  function updateDashboardStats(data) {
    // Calculate stats
    const totalProducts = data.products.length
    const lowStockProducts = data.products.filter((p) => p.stock <= (p.low_stock_threshold || 5)).length

    const today = new Date().toDateString()
    const todaySales = data.sales.filter((s) => new Date(s.date).toDateString() === today)
    const todayRevenue = todaySales.reduce((sum, s) => sum + Number.parseFloat(s.total_amount), 0)

    const pendingRepairs = data.repairs.filter((r) => r.status === "Pending" || r.status === "In Progress").length
    const completedRepairs = data.repairs.filter((r) => r.status === "Completed" || r.status === "Released").length

    const unpaidCommissions = data.commissions
      .filter((c) => c.status === "Unpaid")
      .reduce((sum, c) => sum + Number.parseFloat(c.commission_amount), 0)

    // Update dashboard if stats section exists
    const dashboardSection = document.getElementById("dashboardSection")
    if (dashboardSection && !dashboardSection.querySelector(".stats-grid")) {
      const statsHTML = `
        <div class="stats-grid">
          <div class="stat-card">
            <div class="stat-header">
              <h3>Total Products</h3>
              <div class="stat-icon books">
                <i class="fas fa-box"></i>
              </div>
            </div>
            <div class="stat-value">${totalProducts}</div>
            <div class="stat-description">${lowStockProducts} low stock items</div>
          </div>
          <div class="stat-card">
            <div class="stat-header">
              <h3>Today's Revenue</h3>
              <div class="stat-icon users">
                <i class="fas fa-peso-sign"></i>
              </div>
            </div>
            <div class="stat-value">₱${todayRevenue.toFixed(2)}</div>
            <div class="stat-description">${todaySales.length} transactions</div>
          </div>
          <div class="stat-card">
            <div class="stat-header">
              <h3>Active Repairs</h3>
              <div class="stat-icon issued">
                <i class="fas fa-tools"></i>
              </div>
            </div>
            <div class="stat-value">${pendingRepairs}</div>
            <div class="stat-description">${completedRepairs} completed</div>
          </div>
          <div class="stat-card">
            <div class="stat-header">
              <h3>Unpaid Commissions</h3>
              <div class="stat-icon overdue">
                <i class="fas fa-coins"></i>
              </div>
            </div>
            <div class="stat-value">₱${unpaidCommissions.toFixed(2)}</div>
            <div class="stat-description">Pending payments</div>
          </div>
        </div>
      `
      dashboardSection.querySelector(".content-header").insertAdjacentHTML("afterend", statsHTML)
    }
  }

  await fetchDashboardStats()
})

function setupNavigationEvents() {
  const navButtons = {
    dashboardNavBtn: "dashboard",
    productsNavBtn: "products",
    salesNavBtn: "sales",
    repairsNavBtn: "repairs",
    commissionsNavBtn: "commissions",
    usersNavBtn: "users",
    reportsNavBtn: "reports",
  }
  Object.entries(navButtons).forEach(([buttonId, section]) => {
    const button = document.getElementById(buttonId)
    if (button) {
      button.onclick = () => {
        showSection(section)
        setActiveNavBtn(button)
      }
    }
  })
  const logoutBtn = document.getElementById("logoutBtn")
  if (logoutBtn) logoutBtn.onclick = logout
}

function setActiveNavBtn(activeBtn) {
  document.querySelectorAll(".nav-button").forEach((btn) => btn.classList.remove("active"))
  activeBtn.classList.add("active")
}

function showSection(sectionName) {
  document.querySelectorAll(".content-section").forEach((section) => section.classList.add("hidden"))
  const targetSection = document.getElementById(`${sectionName}Section`)
  if (targetSection) targetSection.classList.remove("hidden")
  if (sectionName === "products") {
    fetchProducts()
    fetchLowStockProducts()
  }
  if (sectionName === "repairs") fetchRepairs()
  if (sectionName === "commissions") fetchCommissions()
  if (sectionName === "users") fetchUsers()
  if (sectionName === "reports") initializeReportFilters()
  if (sectionName === "dashboard") fetchDashboardStats()
}

function logout() {
  if (confirm("Are you sure you want to logout?")) {
    setTimeout(() => {
      window.jobAPI.logout()
      window.jobAPI.navigation.goToPage("./index.html")
    }, 500)
  }
}
// Add further logic for products, sales, repairs, commissions, users, and reports as needed.
