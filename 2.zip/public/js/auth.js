// Login functionality for Cellphone Repair Shop

document.getElementById("loginTab").addEventListener("click", () => {
  showLoginForm();
});

function showLoginForm() {
  document.getElementById("loginTab").classList.add("active");
  document.getElementById("loginForm").style.display = "block";
  clearMessages();
}

function clearMessages() {
  const messages = document.querySelectorAll(".message");
  messages.forEach((msg) => {
    msg.style.display = "none";
    msg.textContent = "";
  });
}

function showMessage(elementId, message, isError = true) {
  const element = document.getElementById(elementId);
  element.textContent = message;
  element.style.display = "block";

  // Auto-hide success messages after 3 seconds
  if (!isError) {
    setTimeout(() => {
      element.style.display = "none";
    }, 3000);
  }
}

function setButtonLoading(buttonId, isLoading) {
  const button = document.getElementById(buttonId);
  const spinner = button.querySelector(".loading-spinner");

  if (isLoading) {
    button.disabled = true;
    spinner.style.display = "inline-block";
  } else {
    button.disabled = false;
    spinner.style.display = "none";
  }
}

// Login form submission
// Only Admin and Cashier accounts are supported

document.getElementById("loginForm").addEventListener("submit", async (e) => {
  e.preventDefault();

  const email = document.getElementById("loginEmail").value.trim();
  const password = document.getElementById("loginPassword").value;

  if (!email || !password) {
    showMessage("loginError", "Please fill in all fields");
    return;
  }

  setButtonLoading("loginBtn", true);
  clearMessages();

  try {
    const result = await window.jobAPI.login({ email, password });

    if (result.success) {
      showMessage("loginSuccess", result.message || "Login successful!", false);
      // The main process will handle navigation automatically
    } else {
      showMessage("loginError", result.message || "Login failed");
    }
  } catch (error) {
    console.error("Login error:", error);
    showMessage("loginError", "An error occurred during login");
  } finally {
    setButtonLoading("loginBtn", false);
  }
});
