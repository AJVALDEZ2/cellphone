// Utility functions for Cellphone Repair Shop

function formatDateTime(dateString) {
  if (!dateString) return "N/A";
  const date = new Date(dateString);
  if (isNaN(date)) return dateString;
  return date.toLocaleString();
}

function showNotification(message, type = "info") {
  document.querySelectorAll(".notification").forEach(n => n.remove());
  const notification = document.createElement("div");
  notification.className = `notification ${type}`;
  notification.innerHTML = `
    <i class="fas fa-${type === "success" ? "check-circle" : type === "error" ? "exclamation-circle" : "info-circle"}"></i>
    <span>${message}</span>
  `;
  document.body.appendChild(notification);
  setTimeout(() => {
    if (notification.parentNode) {
      notification.style.animation = "slideOutRight 0.3s ease";
      setTimeout(() => notification.remove(), 300);
    }
  }, 4000);
}

// Export for browser usage
window.formatDateTime = formatDateTime;
window.showNotification = showNotification;
