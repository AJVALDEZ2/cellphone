"use client"

import  from "../public/js/cashier"

export default function SyntheticV0PageForDeployment() {
  return < />
}